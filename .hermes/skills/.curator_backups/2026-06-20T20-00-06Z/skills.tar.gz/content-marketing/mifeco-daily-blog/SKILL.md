---
name: mifeco-daily-blog
description: "Daily blog post generator for MIFECO.com. Picks a random published book and a random SaaS/consulting topic, writes unique comparative blog posts, generates images via Gemini, and publishes to WordPress. Runs as a cron job."
---

# MIFECO Daily Blog Post Generator

Generates and publishes 2 unique blog posts per day on mifeco.com WordPress:

1. **📚 Book comparison post** — compares a random published book (from pipeline data) against a different book on mifeco.com/books from another series/genre
2. **💻 SaaS External Comparison post** — compares a MIFECO product/service (rotated round-robin) against an EXTERNAL business application (used uniquely until pool exhausted)

Each post includes a Gemini-generated featured image. Deduplication ensures no repeated content.

The internal SaaS-vs-SaaS comparison pattern (Product A vs Product B, both from MIFECO) is kept for backward compatibility but is NOT the default daily post — it may be used during content-staleness fallback or when the external pool is in a reset cycle.

## Data Sources

### Books (from pipeline data)
File: `~/.hermes/pipeline-engine/data/pipeline-books.json`
- Only use books with `"status": "published"` (skip "draft")
- 17 published books across: No Blue Sky (5), Lunar Foundation (4), Age of Lightships (4), Business (3), Standalone (1)

### Books on mifeco.com/books (comparison targets)
Available at `https://www.mifeco.com/books/`:
- **No Blue Sky** (Mars colonization, 5 books): Built from Dust, The Oxygen Gamble, Rivers Under Mars, The Red Charter, The First Martian Nation
- **Lunar Foundation** (Moon settlement, 4 books): Moon Rock, Mooncoming, Water's End, Water's Horizon
- **Age of Lightships** (Space opera, 4 books): Sunward Exodus, The Mercury Accord, Ghosts Beyond Neptune, The Last Photon Fleet
- **Cindy Lou Legal Capers** (Cozy mystery, 3 books): Retainer to Trouble, Clause for Alarm, Affidavits and Alibis
- **Business Books**: Owner's Manual for AI Agents, AI That Works for Small Business, The Crisis Ready Company
- **Memoir**: Tomorrow Remembered
- Free prequel novellas for each series

### SaaS Products on mifeco.com (comparison targets)
Available at `https://www.mifeco.com/`:
- **Project Hypatia Pro** — AI-powered engineering & project management (task allocation, resource optimization, collaboration, risk prediction)
- **PM Accelerator** — Project management accelerator (AI-driven planning, automated updates, smart resource allocation, real-time dashboards)
- **VibraEngineer** — Vibration analysis & diagnostics (AI fault detection, predictive maintenance, multi-sensor fusion)

### Consulting Services on mifeco.com/consult/ (comparison targets)
- **Virtual Consulting ($199)** — Comprehensive business assessment, any issue. 4-hour delivery of 20+ page Assessment + Strategic Plan.
- **AI Readiness Assessment** — Custom evaluation of AI readiness
- **Strategic Planning, Growth Optimization, Digital Transformation, Team Development, Performance Analytics, Risk Management**

### Existing blog posts (dedup)
File: `~/.hermes/pipeline-engine/data/generated-blog-posts.json`
Also check WordPress DB directly (see "Deduplication" section)

## Blog Post Format — COMPARATIVE

### 📚 Book Comparison Post

**Structure:**
- Pick a random published book from pipeline data (Book A)
- Pick a DIFFERENT book from mifeco.com/books (Book B) — must be from a different series or genre
- Write a comparative blog post: "Book A vs Book B: [Compelling Angle]"
- Compare themes, writing style, world-building, character depth, scientific accuracy, emotional impact, etc.
- Both books should be available on Amazon — include CTAs for both
  - **⚠️ Edge case**: Cindy Lou Legal Capers titles are listed on mifeco.com/books but are `status: "draft"` in the pipeline (no Amazon ASIN). When using these as Book B, use MIFECO books page links as fallback CTAs instead of Amazon links.
- Do NOT plagiarize either book — write original comparative analysis
- 600-900 words, HTML format
- Category: "Books"
- Tags: both series names, genre, "MIFECO books", "book comparison"

**Image (cover-inspired):**
Generate a Gemini image that incorporates visual themes from BOTH book covers — a fusion representing the comparison.
```
--mode=cover-inspired
--book-title="Book A vs Book B: [Angle]"
--series="Comparison: [Series A] × [Series B]"
--genre="Science Fiction"
--description="[Theme of Book A] meets [Theme of Book B]: a comparative visual"
--output=/tmp/blog-image-book.png
```

### 💻 SaaS External Comparison Post (Default Daily)

**Structure:**
- Pick a MIFECO product/service using round-robin rotation from the internal pool (starts at index 0)
- Pick a MIFECO consulting service using round-robin rotation (same internal pool, different products/services)
- Pick an external business application NOT yet used (from the external application pool)
- Write a comparative blog post: "{Internal} vs {External App}: Which [Category] Tool Wins for [Use Case]?"

**Blog Post Requirements:**
- 800-1200 words, HTML format
- Category: "Technology" or "Business"
- Tags: internal product name, external app name, "MIFECO", "comparison", "software review"
- Genuine comparative analysis — NOT a sales pitch
- Compare: use cases, features, pricing models, implementation complexity, ideal customer profiles
- Highlight where EACH excels (fair comparison)
- CTA to https://mifeco.com/consult/ for the internal product
- No plagiarism — original analysis

**Slug format:** `{internal-slug}-vs-{external-slug}-comparison` (lowercase, hyphens)

**State File:** `~/.hermes/pipeline-engine/data/saas-comparison-state.json`

**Rotation Logic:**
1. Internal pool (round-robin): Project Hypatia Pro → PM Accelerator → VibraEngineer → Virtual Consulting ($199) → AI Readiness Assessment → Strategic Planning → Digital Transformation → Growth Optimization → Team Development → Performance Analytics → Risk Management → (wrap to start)
2. External pool (used uniquely, reset when exhausted): Microsoft Project, Asana, Jira, Monday.com, Smartsheet, ClickUp, Notion, Trello, Basecamp, Wrike, Teamwork, Airtable, Microsoft Planner, GitHub Projects, Linear, Height, Shortcut, ZenHub, Targetprocess, Planview
3. Read state file → pick internal at `next_internal_index` (modulo) → pick first external NOT in `used_external_apps` → if all used, clear list and pick first → increment index → write state back

See `references/round-robin-state-cron.md` for the full Python rotation implementation.

### 💼 SaaS/Consulting Internal Comparison Post (Fallback/Alternate)

**Structure:**
- Pick a random SaaS product or consulting service from mifeco.com (Product A)
- Pick a DIFFERENT MIFECO product/service (Product B)
- Write a comparative blog post: "Product A vs Product B: Which [MIFECO Solution] Is Right for [Audience]?"
- Compare use cases, features, ideal customer profiles, pricing models, implementation complexity
- Provide genuinely useful guidance — NOT a sales pitch
- Include CTAs to https://mifeco.com/consult/ for both
- 600-900 words, HTML format
- Category: "Business" or "Technology"
- Tags: product names, "MIFECO", "comparison", relevant industry terms

**Image (infographic):**
Generate a Gemini infographic that visually represents the comparison — side-by-side elements, decision flowchart, or feature comparison visual.
```
--mode=infographic
--post-title="Product A vs Product B: [Angle]"
--content-summary="Comparison of [Product A] and [Product B] for [use case]. [Product A] focuses on [X] while [Product B] specializes in [Y]."
--category="Technology"
--output=/tmp/blog-image-saas.png
```

## Infrastructure

### DreamHost SSH
- **Host**: `IAD1-SHARED-B8-42.DREAMHOST.COM`
- **User**: `dh_mwpxuu`
- **Password**: `Rm2214ri####` (from `~/.hermes/.env` as `DREAMHOST_PASSWORD`)
- **Remote path**: `/home/dh_mwpxuu/mifeco.com/`
- **Scripts dir on server**: `/home/dh_mwpxuu/mifeco.com/scripts/`
- **Images dir on server**: `/home/dh_mwpxuu/mifeco.com/images/`
- **Tmp dir on server**: `/home/dh_mwpxuu/mifeco.com/tmp/`

### WordPress
- **DB Name**: `mifeco_com_1`
- **DB User**: `ak48bme`
- **DB Pass**: `7jpetxEL`
- **DB Host**: `mysql.mifeco.com`
- **Table prefix**: `wp_gryu9c_`
- **WP Publish Script**: `/home/dh_mwpxuu/mifeco.com/scripts/wp-publish-post.php`

### Gemini Image Generation
- **Model**: `gemini-2.5-flash-image`
- **API Key env var**: `GOOGLE_AI_STUDIO_KEY` (from `~/.hermes/.env`)
- **Script**: `~/.hermes/pipeline-engine/scripts/generate-blog-image.py`
- **Two modes**: `cover-inspired` (book posts), `infographic` (SaaS/Consulting posts)

## Workflow (execute in order)

### Step 1: Read data files
1. Read `~/.hermes/pipeline-engine/data/pipeline-books.json` → extract all books with `"status": "published"`
2. Read `~/.hermes/pipeline-engine/data/generated-blog-posts.json` → extract existing slugs/titles for dedup

### Step 2: Deduplication check
1. SSH into DreamHost and query existing WP posts (use the **heredoc pattern** - see `references/ssh-mysql-quoting.md`):
   ```python
   # Via python3 heredoc through terminal() — always works
   python3 << 'PYEOF'
   import sys
   sys.path.insert(0, '/home/bob/.hermes/skills/content-marketing/mifeco-daily-blog/scripts')
   from ssh_blog import ssh_run
   result = ssh_run("""mysql -h mysql.mifeco.com -u ak48bme -p7jpetxEL mifeco_com_1 -N -e "SELECT post_title, post_name, post_date FROM wp_gryu9c_posts WHERE post_type='post' ORDER BY post_date DESC;" """)
   print(result)
   PYEOF
   ```
2. Combine with locally stored slugs from `generated-blog-posts.json`
3. Verify the exact slug AND a semantic check on the title don't match any existing post
4. If a comparison between the same two books/products exists, pick different pairings

### Step 3: Select comparison pairs
1. **Book comparison**: 
   - Randomly pick Book A from published pipeline books
   - Pick Book B from mifeco.com/books that is from a DIFFERENT series/genre
   - Ensure this exact pairing hasn't been blogged before
2. **SaaS External comparison**:
   - Read `~/.hermes/pipeline-engine/data/saas-comparison-state.json` (create if missing with `next_internal_index: 0`, `used_external_apps: []`)
   - Pick internal product at `state["next_internal_index"]` modulo 11 (the internal pool size)
   - Pick first external app from pool NOT in `state["used_external_apps"]`; if all used, clear list and pick first
   - Increment `next_internal_index` for next run
   - Ensure this exact pairing hasn't been blogged before (check both generated-blog-posts.json and WP DB)

### Step 4: Write comparative blog posts
Write both posts (Book: 600-900 words, SaaS External: 800-1200 words) in HTML format following the comparative structure above. The SaaS external post uses the format described in the "💻 SaaS External Comparison Post (Default Daily)" section.

### Step 5: Generate images
```bash
# Book post image — use custom --prompt for comparative/fusion images
cd ~/.hermes/pipeline-engine && \
source ~/.hermes/.env && \
python3 scripts/generate-blog-image.py \
  --mode=cover-inspired \
  --prompt="Create a stunning book-cover-inspired illustration that fuses the visual themes of two books... [describe both themes blending]" \
  --output=/tmp/blog-image-book.png

# SaaS External post image — use --mode=infographic with full descriptive summary
cd ~/.hermes/pipeline-engine && \
source ~/.hermes/.env && \
python3 scripts/generate-blog-image.py \
  --mode=infographic \
  --post-title="[Product A] vs [Product B]: [Angle]" \
  --content-summary="Comparison of [Internal Product] (MIFECO [category]) and [External App] for [use case]. [Internal] focuses on [X] while [External] specializes in [Y]." \
  --category="Technology" \
  --output=/tmp/blog-image-saas-external.png
cd ~/.hermes/pipeline-engine && \
source ~/.hermes/.env && \
python3 scripts/generate-blog-image.py \
  --mode=infographic \
  --post-title="Product A vs Product B: [Angle]" \
  --content-summary="Comparison of [A] and [B] for [use case]" \
  --category="Technology" \
  --output=/tmp/blog-image-saas.png
```

**⚠️ Cron-safe key injection**: Always use `source ~/.hermes/.env &&` before the Python command (as shown above). Do NOT paste the raw API key inline — `source` reads the env reliably in cron and background mode. The `GOOGLE_AI_STUDIO_KEY="..."` inline pattern only works in interactive sessions.

**Note**: For comparative images (two books or two products), use `--prompt` with a custom description instead of the structured `--book-title`/`--series` params. The `build_cover_prompt()` helper generates text like "the book 'X' from the 'Y' series" which reads awkwardly when comparing two different works. A custom `--prompt` describing the visual fusion of both themes produces better results.

### Step 6: Upload to DreamHost
Use the helper script `scripts/ssh_blog.py` for all SSH/SCP operations:

```bash
# Create remote dirs
python3 scripts/ssh_blog.py ensure_dirs

# Upload content and image
python3 scripts/ssh_blog.py scp /tmp/blog-content-<slug>.html /home/dh_mwpxuu/mifeco.com/tmp/<slug>.html
python3 scripts/ssh_blog.py scp /tmp/blog-image-*.png /home/dh_mwpxuu/mifeco.com/images/<slug>.png

# Verify files landed
python3 scripts/ssh_blog.py verify <slug>
```

**Verify files landed**: After SCP, run a quick SSH check to confirm the files exist on the remote server before attempting to publish. Failed SCPs (wrong paths, full disk) produce no terminal error output but leave missing files that cause WP publish to fail silently.

**⚠️ Verify one slug at a time**: Do NOT chain multiple `verify` calls in a single shell command (e.g., `python3 ssh_blog.py verify slug1 && python3 ssh_blog.py verify slug2`). Each invocation spawns a new pexpect SSH session, and rapid sequential connections to DreamHost can trigger timeouts. Call verify separately for each slug, or use a single `ssh_run()` via Python heredoc to check both files in one session:
```python
python3 << 'PYEOF'
import sys
sys.path.insert(0, '/home/bob/.hermes/skills/content-marketing/mifeco-daily-blog/scripts')
from ssh_blog import ssh_run
result = ssh_run("ls -la /home/dh_mwpxuu/mifeco.com/tmp/slug1.html /home/dh_mwpxuu/mifeco.com/images/slug1.png /home/dh_mwpxuu/mifeco.com/tmp/slug2.html /home/dh_mwpxuu/mifeco.com/images/slug2.png", timeout=30)
print(result)
PYEOF
```

### Step 7: Publish to WordPress
Use the helper script for WP publishing (handles quoting and 240s timeout):

```bash
python3 scripts/ssh_blog.py wp_publish \
  "Post Title" \
  "<slug>" \
  "Category" \
  "tag1,tag2,tag3" \
  "/home/dh_mwpxuu/mifeco.com/tmp/<slug>.html" \
  "/home/dh_mwpxuu/mifeco.com/images/<slug>.png"
```

The script wraps the PHP call with correct double-quote escaping and uses a 240s timeout for the PHP upload.

### Step 8: Record the posts
Append both new posts to `~/.hermes/pipeline-engine/data/generated-blog-posts.json`:
```json
{
  "title": "...",
  "slug": "...",
  "type": "book" | "saas" | "saas-external" | "consulting",
  "comparison": "Book A vs Book B" | "Product A vs Product B" | "Product A vs External App",
  "wordpress_id": 42,
  "wordpress_url": "https://www.mifeco.com/slug/",
  "image_path": "images/filename.png",
  "generated_at": "2026-06-08T...",
  "excerpt": "First 2-3 sentences..."
}
```

Also update `~/.hermes/pipeline-engine/data/saas-comparison-state.json` (the rotation state) after a successful external SaaS publish — write back the new `next_internal_index`, the `used_external_apps` list with the consumed app appended, and the updated `last_run` timestamp.

**⚠️ JSON append with `patch`**: The `patch` tool with `mode=replace` CAN reliably append to JSON arrays. Use a unique `old_string` (e.g., the last entry's closing `}` + comma + `]`) and include the new objects before the closing `]`. Always validate with `python3 -c "import json; json.load(open('file'))"` after patching. Index `[0]` is a metadata dictionary — always preserve it. As a fallback if `patch` fails on complex structures, use `write_file` with the full file content (read → parse → append → write).

**⚠️ `write_file` corrupts `***`**: The `write_file` tool silently corrupts lines containing `***` (triple asterisks). This affects any Python script that captures `DREAMHOST_PASSWORD` from `.env` via `subprocess.run`, and has been observed in JSON files containing `***` patterns. To write scripts that use the password, use `terminal("python3 << 'PYEOF'")` heredoc pattern instead of `write_file`. For data files, verify no `***` sequences exist before using `write_file`.

### Step 9: Report
Output a summary (under 400 words):
- Book post: title, comparison pair, WP URL, image
- SaaS/Consulting post: title, comparison pair, WP URL, image
- Any dedup skips
- Errors if any

## MySQL Query Quoting Through SSH

MySQL queries with WHERE clauses (especially `WHERE post_type='post'`) are notoriously brittle through pexpect SSH. The shell strips quoting levels before MySQL sees them.

**Buggy pattern (fails — MySQL sees `post` as a column name instead of keyword `post`):**
```python
# DON'T — the inner single quotes break the shell string
ssh_run('mysql ... -e "SELECT ... WHERE post_type=\\'post\\';"')
```

**Recommended pattern (always works):**
```bash
# Use a Python heredoc through terminal()
cd /home/bob && python3 << 'PYEOF'
import sys
sys.path.insert(0, '/home/bob/.hermes/skills/content-marketing/mifeco-daily-blog/scripts')
from ssh_blog import ssh_run
result = ssh_run("""mysql -h mysql.mifeco.com -u ak48bme -p7jpetxEL mifeco_com_1 -N -e "SELECT post_title, post_name FROM wp_gryu9c_posts WHERE post_type='post' ORDER BY post_date DESC;" """)
print(result)
PYEOF
```

See `references/ssh-mysql-quoting.md` for the full quoting reference with all proven patterns.

## SSH/SCP Execution Pattern

**Helper script**: `scripts/ssh_blog.py` (in this skill's `scripts/` directory) provides reusable `ssh_run()`, `scp_upload()`, `ensure_remote_dirs()`, `verify_uploads()`, and `wp_publish()` functions. Use it instead of rewriting pexpect logic each run.

**⚠️ Do NOT hardcode passwords.** The `write_file` tool corrupts lines containing `***`. Always read credentials from `.env` at runtime:

```python
import pexpect
import subprocess

DHP = 'dh_mwpxuu@IAD1-SHARED-B8-42.DREAMHOST.COM'
REMOTE_BASE = '/home/dh_mwpxuu/mifeco.com'

# Read password at runtime (never hardcode)
result = subprocess.run(
    ['bash', '-c', 'source ~/.hermes/.env && echo "$DREAMHOST_PASSWORD"'],
    capture_output=True, text=True, timeout=10
)
PASSWORD = result.stdout.strip()

def ssh_run(command, timeout=60):
    child = pexpect.spawn('ssh', [
        '-o', 'StrictHostKeyChecking=accept-new',
        DHP, command
    ], timeout=timeout)
    child.expect('password:')
    child.sendline(PASSWORD)
    child.expect(pexpect.EOF, timeout=timeout)
    return child.before.decode()

def scp_upload(local_path, remote_path):
    child = pexpect.spawn('scp', [
        '-o', 'StrictHostKeyChecking=accept-new',
        local_path,
        f'{DHP}:{remote_path}'
    ], timeout=60)
    child.expect('password:')
    child.sendline(PASSWORD)
    child.expect(pexpect.EOF, timeout=60)
    output = child.before.decode() if child.before else ''
    if 'failed to upload' in output.lower() or 'no such file' in output.lower():
        return False
    return True
```

**IMPORTANT**: Always create remote directories before SCP:
```python
ssh_run("mkdir -p /home/dh_mwpxuu/mifeco.com/tmp /home/dh_mwpxuu/mifeco.com/images")
```

**WordPress publishing**: The WP REST API returns 404 (SPA intercepts all routes). Must use PHP CLI directly on the server via `wp-load.php`. The `wp_create_category()` function requires including `wp-admin/includes/taxonomy.php`.

**WP publish argument quoting**: The PHP `getopt()` parser requires **double-quoted** argument values when called through SSH/pexpect. Pass `--title="Post Title"` not `--title='Post Title'`. In Python pexpect scripts, wrap the entire shell command in single-quoted strings so double quotes pass through to the remote shell:
```python
cmd = (
    'cd /home/dh_mwpxuu/mifeco.com && '
    'php scripts/wp-publish-post.php '
    '--title="Post Title" '  # double quotes inside single-quoted string
    '--slug="post-slug" '
)
```

**`.env credential store blocks read_file`**: `read_file("~/.hermes/.env")` returns "Access denied". Use `terminal("source ~/.hermes/.env && ...")` for env-consuming commands, or `terminal("cat ~/.hermes/.env | grep KEY_NAME")` to extract individual values.

**Gemini image generation**: Uses `gemini-2.5-flash-image` model via Google AI Studio API (`GOOGLE_AI_STUDIO_KEY` from `~/.hermes/.env`). Returns base64-encoded PNG. Two modes: `cover-inspired` (book posts) and `infographic` (SaaS/consulting posts).

**CRITICAL: `--mode` is REQUIRED even with `--prompt`**. The script's argparse enforces `--mode` as a mandatory positional. Omitting it causes `error: the following arguments are required: --mode` even when providing a custom `--prompt`. Always include `--mode=cover-inspired` or `--mode=infographic`.

**For comparative/fusion images (two books or two products)**, use `--prompt` with a custom description instead of the structured `--book-title`/`--series` params. The `build_cover_prompt()` helper generates text like "the book 'X' from the 'Y' series" which reads awkwardly when comparing two different works. A custom `--prompt` describing the visual fusion of both themes produces better results:
```bash
python3 scripts/generate-blog-image.py \
  --mode=cover-inspired \
  --prompt="Create a stunning book-cover-inspired illustration that fuses the visual themes of two books... [describe both themes blending]" \
  --output=/tmp/blog-image-book.png
```

- If image generation fails → publish post without featured image
- If WP publish returns duplicate slug error → modify slug (add suffix) and retry
- If SSH times out → retry once, then report error and continue
- **SCP timeout for large images**: The `scp_upload()` function uses a 60s default timeout. Gemini `cover-inspired` images can be ~2MB and may exceed this. If SCP times out on the first attempt, retry with a longer timeout by calling `scp_upload()` with a longer timeout parameter (e.g., 180s), or use a direct pexpect spawn with a custom timeout. The upload usually succeeds on the second attempt. Do NOT assume a timeout means the file failed to upload — always verify with `ls -la` on the remote before retrying.
- Always record successfully published posts even if one of the two fails

- `references/round-robin-state-cron.md` — Round-robin state file pattern for cron jobs that rotate through item pools across runs
- `references/cron-execution-log-2026-06-20.md` — Successful end-to-end cron execution example with concrete outputs and state transitions

## Prerequisites

Before running this skill (especially in cron mode), verify `pexpect` is installed:

```bash
pip3 install pexpect
```

The `scripts/ssh_blog.py` helper imports `pexpect` at the top level. If it's missing, SSH/SCP operations will fail with `ModuleNotFoundError`. This is a one-time install — the package persists across sessions.

## Cron Mode Pitfalls

This skill frequently runs as a cron job. In cron mode, several tools behave differently:

1. **`execute_code` is BLOCKED** — Do not write SSH/SCP operations inside an `execute_code` call. **Use the helper script `scripts/ssh_blog.py`** which is designed for cron-safe execution. If you need custom pexpect logic, use `terminal()` with a Python heredoc (`python3 << 'PYEOF'`) — do NOT write standalone scripts with `write_file` because it corrupts lines containing `***` (which appears in any script that reads `DREAMHOST_PASSWORD` from `.env`). See the working pattern in Step 2 (Deduplication) and Step 6 (Upload) of this skill.

2. **Long timeouts for WP publishing** — The `wp-publish-post.php` PHP script takes 60-180 seconds. The `scripts/ssh_blog.py` `wp_publish()` function uses a 240s timeout. If calling `ssh_run()` directly, override to 240s for publish commands:
   ```python
   result = ssh_run(publish_cmd, timeout=240)  # not the default 60
   ```

3. **No user present** — Cannot ask for clarification or approval. Make reasonable decisions (pick comparisons randomly, handle errors gracefully). If SSH/SCP fails, retry once then report the error and continue with the other post.

4. **SCP timeouts on large image uploads** — Gemini-generated `cover-inspired` images can be ~2MB. The default SCP timeout (60s) may not be enough for DreamHost's connection speed. If an SCP upload times out, retry once with a longer timeout (180s) before reporting failure. Use `scp_upload(path, path, timeout=180)` or a direct pexpect call.

5. **Final report is auto-delivered** — Keep under 400 words. If nothing to report, output exactly `[SILENT]` (nothing else).

## Social Media Cross-Posting

After publishing a blog post to WordPress, use the `social-direct-publisher` skill to cross-post to social media.

### Auto-Generate Social Posts from Blog Content

For each published blog post, generate:

**LinkedIn post:**
- Professional angle on the blog topic
- 2-3 sentence hook + key insight
- Link to the full blog post on mifeco.com
- Hashtags: relevant topic tags
- Campaign tag: `blog-[post-slug]`

**Facebook post:**
- Conversational summary of the blog post
- Question to engage readers
- Link to the full blog post
- Campaign tag: `blog-[post-slug]`

**Instagram post:**
- Visual: Use the blog post's featured image or generate a new social-specific image
- Caption: Short teaser + "Link in bio" for the full post
- Campaign tag: `blog-[post-slug]`

### Workflow Integration

After Step 7 (Publish to WordPress) and Step 8 (Record the posts):
1. Generate social post content for all 3 platforms
2. Submit to `social-direct-publisher` as drafts (approval mode: `approve_then_publish`)
3. Include blog post URL as the link
4. Bob approves → social publisher publishes via API
5. Log social post URLs in the blog post record

### Image Reuse

The Gemini-generated blog post image (from Step 5) can be reused for social media:
- LinkedIn: Use as-is (1200×627 recommended, will be cropped)
- Facebook: Use as-is (1200×630 recommended)
- Instagram: Crop to 1080×1080 or 1080×1350

Generate platform-specific crops using the image generation script's `--mode=social` flag if available.

## Cron Delivery
This skill runs as a cron job. Final output is delivered automatically.
Keep the final report under 400 words.
