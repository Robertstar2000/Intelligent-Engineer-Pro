# React SPA Bundle Modification — Session Pattern

## What Was Done

Added "Virtual Consulting" (`/consult`) and "Books" (`/books`) links throughout the main mifeco.com React SPA by modifying the minified JS bundle in-place.

## Exact Changes Made

1. **Desktop nav**: Added `Virtual Consulting` link after `Books`, changed `#bookstore` anchor to `/books` external link
2. **Mobile nav**: Same changes as desktop
3. **Hero section**: Added "Virtual Consulting — $199" CTA button (green gradient)
4. **Products & Services section**: Changed grid from 3-column to 4-column, added Virtual Consulting card
5. **Footer**: Added Virtual Consulting and Books links

## Python Pattern Used

```python
with open('/tmp/mifeco_bundle.js', 'r') as f:
    bundle = f.read()

# Always verify the exact string exists before replacing
old = 'exact string from bundle'
count = bundle.count(old)
assert count > 0, f"String not found: {old[:80]}"

bundle = bundle.replace(old, new_string, count)

with open('/tmp/mifeco_bundle_modified.js', 'w') as f:
    f.write(bundle)
```

## Key Strings Found in Bundle

| Purpose | String (exact) |
|---------|--------|
| Desktop Books nav | `l.jsx("a",{href:"#bookstore",className:"text-gray-600 hover:text-blue-600 transition-colors",children:"Books"})` |
| Mobile Books nav | Same but `className:"block text-gray-600...` |
| Hero CTA | `children:"Consult with an Expert"` |
| Products grid | `className:"grid md:grid-cols-3 gap-8 max-w-6xl mx-auto"` |
| Footer services end | `children:"Team Development"})})` |

## Deployment

Upload via SFTP to `/home/dh_mwpxuu/mifeco.com/assets/index-HASH.js` — the filename hash must match what `index.html` references.

## Verification

```bash
curl -s "https://www.mifeco.com/assets/index-HASH.js" | grep -c "Virtual Consulting"
curl -s "https://www.mifeco.com/assets/index-HASH.js" | grep -c 'href:"/books"'
curl -s "https://www.mifeco.com/assets/index-HASH.js" | grep -c 'href:"#bookstore"'  # should be 0
```

## Important Notes

- Bundle hash changes on React rebuild — changes are lost if site is redeployed from source
- Always download the current bundle before modifying
- Use `execute_code` (Python) for string manipulation, not sed — more reliable for large files
- Verify exact string exists with `.count()` before replacing
- After upload, verify by downloading the live bundle again and grepping for changes
