# Observed File Structures for Novel Writing Projects

Based on actual book projects in the filesystem, here are the observed directory structures:

## Standard Structure (Books 2 & 3)
- `/home/bob/books/[Project_Directory]/book-sources/Chapter_XX_[Title].md`
- Examples:
  - Book 2 (Second Generation): `/home/bob/books/Second_Generation/book-sources/`
  - Book 3 (Third Generation): `/home/bob/books/Third_Generation/book-sources/`

## Alternative Structure (Book 1)
- `/home/bob/books/[Project_Directory]/[Manuscript_Files]` 
- Examples:
  - Book 1 (First Generation): `/home/bob/books/Martian_Sovereignty_Final_Package/First_Generation_Manuscript.md`
  - Cover files also in same directory: `First_Generation_Cover.png`

## Book 4 & 5 Structure
- Located in subdirectories of `Moon_Base_One/`:
  - Book 4 (The Red Charter): `Moon_Base_One/Moon_Base_The_Beginning/`
  - Book 5 (The First Martian Nation): `Moon_Base_One/Moon_Base_Homecoming/`

## Key Insight
Always verify the specific book directory structure before assuming file locations. The novel-writing workflow should adapt to the actual project organization rather than enforcing a rigid path pattern.