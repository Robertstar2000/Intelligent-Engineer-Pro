# Vite SPA Component Patterns for mifeco.com

This file documents the component patterns used in the mifeco.com Vite React SPA for future modifications.

## BookstoreSection Component

Location: `mifeco-website/src/components/BookstoreSection.jsx`

### Structure
The BookstoreSection defines books as a JS data structure grouped into series categories:
- `BOOKS.noBlueSky` — 5 books (Built from Dust through The First Martian Nation)
- `BOOKS.lunarFoundation` — 4 books (Moon Rock through Waters Horizon)
- `BOOKS.business` — 2 books (Owner's Manual for AI Agents, AI That Works for Small Business)  
- `BOOKS.memoir` — 1 book (Tomorrow Remembered)

### Per-book fields
```js
{
  title: "Book Title",
  subtitle: "Series subtitle or tagline",
  published: true,         // or false
  kindleUrl: "https://...", // only used when published=true
  description: "Short description for the card"
}
```

### Published vs. Available Soon
- `published: true` → Green "Published" badge + orange "Buy on Amazon Kindle" button linking to `kindleUrl`
- `published: false` → Amber "Available Soon" badge + disabled grey button

### Amazon URLs
The `AMAZON_AUTHOR` constant at the top of the file points to the author's Amazon store page. Individual book ASINs can replace the author link once books are live:
```js
kindleUrl: 'https://www.amazon.com/dp/B0XXXXXXXX' // replace with actual ASIN
```

### Import in App.jsx
```jsx
import BookstoreSection from './components/BookstoreSection';
// Insert in JSX: <BookstoreSection />
```

## SoftwareSection Component

Location: `mifeco-website/src/components/SoftwareSection.jsx`

### Structure
The SoftwareSection now shows 3 real MIFECO SaaS apps, not the generic Researcher/Hyperion/Engineering Assistant:

```js
const SAAS_APPS = [
  {
    id: 'hypatia',
    name: 'Project Hypatia Pro',
    subtitle: 'AI-Powered Engineering & Project Management',
    icon: <Rocket className="w-8 h-8" />,
    color: 'from-purple-600 to-pink-500',
    bgColor: 'bg-purple-50',
    appUrl: 'https://project-hypatia-pro-1064319572465.us-west1.run.app',
  },
  // ... PM Accelerator, VibraEngineer
];
```

Each app points to its Cloud Run URL. Original Stripe checkout / purchase flow was removed since these are browser-hosted apps (no download needed).

## Navigation Updates

When adding a new section:
1. Add a nav link in both desktop nav (`<nav className="hidden md:flex...">`) and mobile nav (`<div className="md:hidden...">`)
2. Use `href="#sectionname"` for scroll-to-section behavior
3. Desktop nav lists nav links as `<a>` tags inside `<nav>`. The "Industries" dropdown is a `<button>` inside a `<div className="relative">` — preserve this structure when inserting new links between Services and Industries.

## Key Imports

| Component | File | Import path |
|-----------|------|-------------|
| BookstoreSection | `src/components/BookstoreSection.jsx` | `./components/BookstoreSection` |
| SoftwareSection | `src/components/SoftwareSection.jsx` | `./components/SoftwareSection` |
| Card, Badge, Button | shadcn/ui | `./components/ui/card`, etc. |

## Build & Deploy Quick Reference

```bash
cd ~/mifeco_web/mifeco-website

# Build (prefer npm if pnpm blocks builds)
rm -rf node_modules pnpm-lock.yaml
npm install --legacy-peer-deps
npx vite build

# Deploy via rsync (within execute_code(), not terminal())
# rsync -avz --rsh="ssh -o StrictHostKeyChecking=accept-new" dist/ dh_mwpxuu@host:/home/dh_mwpxuu/mifeco.com/
# ⚠️ NEVER use --delete — WordPress co-located in web root
```
