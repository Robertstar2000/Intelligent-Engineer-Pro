---
name: hermes-model-config
description: Fix and understand Hermes Agent model configuration — the config schema, how model resolution works, and the separate fallback_providers mechanism.
category: devops
---

# Hermes Model Configuration

When the LLM is stuck, using the wrong model, or falling back incorrectly, fix the model configuration in `~/.hermes/config.yaml`.

## Config Schema Structure

The `model:` key accepts **two formats** — Hermes handles both:

**Format A — Flat string (simpler):**
```yaml
model: "provider/model-name:tag"    # e.g. "deepseek/deepseek-v4-flash"
```
The provider is determined automatically from the model prefix (e.g. `deepseek/` → OpenRouter).

**Format B — Nested dict (full control):**
```yaml
model:
  default: "provider/model-name:tag"    # primary model
  provider: "openrouter"                # or "anthropic", "openai", etc.
  base_url: "https://openrouter.ai/api/v1"
  api_mode: chat_completions
```

Both work. Flat string is simpler for most setups. Nested dict is needed when you must override the provider, base URL, or API mode.

## CRITICAL: Fallback uses a TOP-LEVEL key

The fallback model is NOT under `model:`. It is a top-level key `fallback_providers`:

```yaml
# WRONG - model.fallback does NOT exist in Hermes code
model:
  default: some-model:free
  fallback: some-model-paid      # <-- THIS KEY IS IGNORED

# CORRECT - fallback_providers is top-level
fallback_providers:
- provider: openrouter
  model: some-model-paid         # no :free tag, paid fallback
```

The source code reads:
- `_resolve_gateway_model()` (gateway/run.py:420) reads `model.default` then `model.model`
- `_load_fallback_model()` (gateway/run.py:1047) reads TOP-LEVEL `fallback_providers` or `fallback_model`

## Pitfalls

### Comma-separated string in model.model
If `model.model` is a comma-separated string like `"model-a:free, model-a"`, it gets parsed as a single string and causes failures. Delete the `model.model` key entirely.

### Wrong key name for fallback
`model.fallback` does NOT exist. The fallback mechanism reads from:
1. Top-level `fallback_providers` (list of `{provider, model}` dicts) — preferred
2. Top-level `fallback_model` (legacy single dict) — deprecated

### Config version matters
The `model:` section must be a dict, not a flat string. Older configurations may have `model: "some-model"` as a bare string at the top level — the code handles both formats.

## Verification

```bash
cd ~/.hermes && python3 -c "
import yaml
with open('config.yaml') as f:
    cfg = yaml.safe_load(f)
m = cfg.get('model', {})
print('model.default:', m.get('default'))
print('model.provider:', m.get('provider'))
print('fallback_providers:', cfg.get('fallback_providers'))
print('model.model (should not exist):', m.get('model', 'CORRECT - absent'))
"
```

Then restart: `sudo systemctl restart hermes-gateway`

## Key Source Locations

- Config defaults: `hermes-cli/config.py` (`DEFAULT_CONFIG` dict - shows expected schema)
- Model resolution: `gateway/run.py` `_resolve_gateway_model()` (line 420)
- Fallback loading: `gateway/run.py` `_load_fallback_model()` (line 1047)
- Fallback chain: `run_agent.py` `AIAgent.__init__()` (reads `fallback_model` parameter, line 596)