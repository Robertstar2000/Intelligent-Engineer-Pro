---
name: php-admin-dashboard-deployment
title: PHP Admin Dashboard Deployment on Shared Hosting
description: Deploy static HTML dashboards behind a PHP session-based password gate on shared hosting (co-located with WordPress), with a PHP webhook endpoint for agent-triggered data refresh.
tags: [deployment, dashboard, php, password-gate, webhook, shared-hosting, dreamhost, wordpress]
related_skills:
  - devops/wordpress-pipeline-integration
  - devops/webhook-subscriptions
  - business/sales-pipeline-infrastructure
triggers:
  - "User has static HTML dashboards with embedded JSON data and wants them live on a shared hosting site"
  - "User wants a password-protected admin area on their WordPress site that's separate from wp-admin"
  - "Deploy pipeline dashboards, content command centers, or admin panels to a shared hosting server"
  - "Create a PHP webhook endpoint on shared hosting that an agent or external service can POST data to"
  - "Set up recurring rsync-based sync from an agent machine to a shared hosting server for dashboard updates"
  - "User has WordPress on DreamHost (or similar) and needs admin dashboards deployed alongside it"
  - "Protect static HTML files with a single-password session-based PHP gate"
  - "Build a content dashboard with view/approve/send/delete buttons and 3-state approval workflow"
  - "User wants to replace alert()-based placeholder links with live interactive modals (intake forms, email sequences, architecture docs)"
  - "User wants visual infographic metrics sections on content cards (X posts, blog posts, LinkedIn posts)"
  - "User wants to correct book titles or add missing books to a pipeline dashboard catalog"
  - "User wants sidebar navigation cleanup — removing duplicate alert-based links"
  - "Deploy static HTML forms, JSON sequence files, and markdown docs to the server alongside dashboards"
---

# PHP Admin Dashboard Deployment on Shared Hosting

Deploy static HTML dashboards behind a PHP password gate on shared hosting, with a webhook endpoint for agent-triggered data refresh.

## Architecture

```
Agent Machine (Hermes)                 Shared Hosting (e.g., DreamHost)
┌──────────────────────┐               ┌──────────────────────────────┐
│ pipeline-engine/     │  rsync -avz   │ /home/user/domain.com/admin/ │
│   dashboard/         │ ───────────→  │   index.php     ← Password gate│
│   data/*.json        │               │   dashboard.html ← Live data │
│   scripts/           │               │   webhook.php   ← POST endpoint│
│     dashboard-sync.sh│               │   .htaccess     ← Security   │
└──────────────────────┘               └──────────────────────────────┘
        │                                       │
        │  Webhook POST (data refresh)          │
        └───────────────────────────────────────┘
```

## Key Components

### 1. PHP Password Gate (`index.php`)

A session-based single-password gate that protects all admin pages:

- PHP sessions with configurable timeout (default 2 hours)
- Single password hardcoded in the file (one gate, not multi-user)
- On successful login: redirect to the specified dashboard HTML page
- Logout support
- Clean dark-themed login form matching the dashboard design
- Session cookie: HttpOnly + SameSite=Strict

**Password storage:** Hardcoded in the PHP file (single-user, single-password). Use a strong password — it's the only barrier between the public internet and your data.

**Session management:**
```php
session_start();
$ADMIN_PASSWORD = 'your-strong-password-here';
$SESSION_TIMEOUT = 7200; // 2 hours

// Check timeout on each request
if (time() - $_SESSION['login_time'] > $SESSION_TIMEOUT) {
    session_destroy();
    header('Location: ?expired=1');
    exit;
}
```

### 2. Static Dashboard HTML

The dashboards are self-contained HTML files with data embedded as JavaScript objects in `<script>` tags. No database, no server-side rendering. Data is embedded fresh on each sync.

**Data embed pattern:**
```html
<script>
// ===== LIVE PIPELINE DATA =====
const saasPipeline = { ... };  // From pipeline-saas.json
const consultingPipeline = { ... };
const booksPipeline = { ... };
</script>
```

### 3. PHP Webhook Endpoint (`webhook.php`)

A PHP endpoint that the agent can POST data to:

**Endpoints:**
| Method | Action | Description |
|--------|--------|-------------|
| GET | Health check | Returns `{"status": "ok", "timestamp": "..."}` |
| POST | `action: "ping"` | Ping test with secret validation |
| POST | `action: "refresh"` | Touch dashboard files to signal freshness |
| POST | `action: "sync"` | Write JSON data files to `data/` directory |

**Security:**
- Secret token in payload (not in URL or headers — avoids logging)
- 403 on invalid secret
- CORS headers for cross-origin access
- OPTIONS preflight support

**Pattern:**
```php
$SECRET = 'your-webhook-secret';
$input = json_decode(file_get_contents('php://input'), true);
if (!isset($input['secret']) || $input['secret'] !== $SECRET) {
    http_response_code(403);
    exit(json_encode(['status' => 'error', 'message' => 'Invalid secret']));
}
```

### 4. .htaccess Security

Protect the admin directory:
- Allow direct access to webhook.php (no session needed)
- Allow static assets (CSS, JS, images)
- Block direct access to `data/` directory
- Block direct PHP file access except index.php and webhook.php

### 5. Sync Script (rsync from agent to server)

A script on the agent machine that:
1. Reads the latest pipeline data from local JSON files
2. Rsyncs the dashboard directory to the server
3. Optionally triggers the webhook for data refresh

**Rsync with password (no sshpass):**
```python
import pexpect
child = pexpect.spawn(f'rsync -avz --rsh="ssh -o StrictHostKeyChecking=accept-new" '
    f'{local_dir}/ {user}@{host}:{remote_dir}')
child.expect_exact("password:")
child.sendline(password)
child.expect(pexpect.EOF)
```

**⚠️ NEVER use `--delete` flag** when rsyncing to a directory co-located with WordPress. It will delete all WordPress files.

## File Structure on Server

```
/var/www/domain.com/admin/
├── index.php                       # Password gate → login or menu
├── pipeline-dashboard.html         # Dashboard with embedded data
├── content-command-center.html     # Content management dashboard
├── webhook.php                     # Webhook endpoint
├── .htaccess                       # Security rules
└── data/                           # Synced JSON data (webhook writes here)
    ├── pipeline-saas.json
    ├── pipeline-books.json
    └── ...
```

## Cron Schedule

| Time | Job | Action |
|------|-----|--------|
| Daily (30 min after pipeline run) | Dashboard Sync | rsync dashboard files + trigger webhook refresh |

## Approval Workflow UI Pattern

For content dashboards (emails, social posts, blog drafts) where nothing should go live without explicit sign-off, implement this **3-state approval workflow**.

### State Management (localStorage)

```javascript
const LS_KEY = 'mifeco_content_center_v2';

function loadState() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    return raw ? JSON.parse(raw) : { approved: {}, sent: {}, deleted: {} };
  } catch(e) { return { approved: {}, sent: {}, deleted: {} }; }
}

let state = loadState();

function isApproved(id) { return state.approved[id] === true; }
function isSent(id)     { return state.sent[id] === true; }
function isDeleted(id)  { return state.deleted[id] === true; }
function markApproved(id) { state.approved[id] = true; saveState(state); }
function markSent(id)     { state.sent[id] = true; saveState(state); }
function markDeleted(id)  { state.deleted[id] = true; saveState(state); }
```

### Three-State Flow

```
🟦 Pending → [View] [Approve] [Delete]
         ↓ (click Approve → confirm modal)
🟧 Approved → [View] [✔ Approved] [Send Now] [Delete]
         ↓ (click Send Now → confirm modal → webhook notification)
🟩 Sent → [View] [✓ Sent] (all actions disabled)
```

**State transitions:**
- **Pending:** Default. Item shows amber "Approve" button. "Send" button is hidden.
- **Approved:** After clicking Approve. Item gets an amber border + "✔ Approved" overlay. "Send Now" button appears.
- **Sent:** After clicking Send. Item gets a green border + "✓ Sent" overlay. All action buttons disabled.

### Card Button Pattern

Each card renders 3-4 buttons depending on state:

```javascript
function buildCardActions(viewer, id) {
  const approved = isApproved(id);
  const sent = isSent(id);

  // View — always visible
  let html = `<button onclick="openViewModal('${viewer}','${id}')">👁 View</button>`;

  if (sent) {
    html += `<button disabled>✓ Sent</button>`;
  } else if (approved) {
    html += `<button class="approved-done">✔ Approved</button>`;
    html += `<button onclick="confirmAction('${viewer}','${id}','send')">📤 Send Now</button>`;
    html += `<button onclick="confirmAction('${viewer}','${id}','delete')">🗑 Delete</button>`;
  } else {
    html += `<button onclick="confirmAction('${viewer}','${id}','approve')">✔ Approve</button>`;
    html += `<button onclick="confirmAction('${viewer}','${id}','delete')">🗑 Delete</button>`;
  }
  return html;
}
```

### View Modal

A full-content overlay that shows the complete item (subject, body, keywords, metadata) with inline actions:

- **Status badge:** Shows current state (⏳ Pending Approval / ✔ Approved / ✓ Sent) with color coding
- **Metadata row:** Type, pipeline, day, target type, book title, CTA — whatever is relevant
- **Body panel:** Full content with highlighted `{{placeholders}}` in accent color, monospace whitespace preservation (`white-space: pre-wrap`)
- **Keywords panel:** Flex-wrap list of tags below the body
- **Footer buttons:** Same approve/send/delete buttons as the card — closes the modal first, then opens the confirmation modal
- **Escape key** closes the view modal
- **Overlay click** closes the view modal
- **Responsive:** 720px max-width, scrollable on mobile

```javascript
function openViewModal(viewer, id) {
  const item = getItem(viewer, id);
  if (!item) return;

  // Populate header (subject/meta), status badge, body with highlighted placeholders,
  // keyword tags, and matching footer buttons
  document.getElementById('vmSubject').textContent = item.subject || item.title;
  document.getElementById('vmBody').innerHTML = highlightPlaceholders(item.body || item.copy);
}
```

### Confirmation Modal

A three-modal-style confirmation system (one reusable overlay, three configurations):

| Action | Title | Description | Confirm Button |
|--------|-------|-------------|----------------|
| **Approve** | "Approve this email?" | "You are approving this content for publication. Once approved, the Send button will become active. Nothing will be sent yet." | `✔ Approve` (amber) |
| **Send** | "Send this email now?" | "This content has been approved. Clicking Send will dispatch it via the webhook. This cannot be undone." | `📤 Send Now` (accent) |
| **Delete** | "Remove from queue?" | "This will permanently remove the item with a slide-out animation." | `🗑 Delete` (red) |

### Sidebar Stats

Include approved count alongside total/sent/queued:

```
Total Items: 38
Approved:    3   ← new amber-colored stat
Sent:        12
Queued:      23  ← remaining pending items
```

### Visual Styling

- **Approved cards:** Amber border (`#f59e0b`), amber overlay badge, amber background tint
- **Sent cards:** Green border (`#22c55e`), green overlay badge, green background tint
- **Pending cards:** Default dark card with amber "Approve" button
- **View modal:** Dark overlay (85% opacity), inner card with close button, status badges with color-coded backgrounds
- **Buttons:** View (purple outline), Approve (amber fill), Send (accent/fill), Delete (red outline)

### Webhook Notification on Send

When an item is sent, POST a fire-and-forget notification to the webhook endpoint:

```javascript
function notifyWebhook(viewer, id, action) {
  const item = getItem(viewer, id);
  if (!item) return;

  fetch('/admin/webhook.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      secret: 'your-webhook-secret',
      action: 'content_action',
      content: { viewer, item_id: id, action, timestamp: new Date().toISOString() }
    })
  }).catch(() => {}); // Fire-and-forget
}
```

### State Persistence Keying

Always version the localStorage key so old state doesn't collide with new schema:

```javascript
const LS_KEY = 'mifeco_content_center_v2'; // Increment on schema change
```

---

## Pipeline Dashboard Modals

When building a multi-section pipeline dashboard, replace `alert()`-based placeholder links with live interactive modals. The three common modal patterns are:

### 1. Intake Form Modal (iframe)

Opens a self-contained HTML form in an iframe within a modal overlay. The form submits directly to AgentMail via its own JavaScript — no additional backend needed.

**CSS:**
```css
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.8);z-index:300;align-items:center;justify-content:center;padding:20px}
.modal-overlay.show{display:flex}
.modal-content{background:#1e293b;border:1px solid #334155;border-radius:12px;max-width:800px;width:100%;max-height:85vh;overflow:hidden;display:flex;flex-direction:column;position:relative}
.modal-header{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid #334155;flex-shrink:0}
.modal-header h3{font-size:16px;font-weight:700;color:#e2e8f0}
.modal-close-btn{background:transparent;border:1px solid #334155;color:#94a3b8;width:32px;height:32px;border-radius:6px;cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;transition:all .15s}
.modal-close-btn:hover{background:#ef4444;color:#fff;border-color:#ef4444}
.modal-body{flex:1;overflow-y:auto;padding:20px}
.modal-body iframe{width:100%;height:100%;border:none;min-height:60vh;border-radius:8px;background:#0f172a}
```

**HTML:**
```html
<!-- Form Modal -->
<div class="modal-overlay" id="formModal">
  <div class="modal-content">
    <div class="modal-header">
      <h3 id="formModalTitle">Intake Form</h3>
      <button class="modal-close-btn" onclick="closeModals()">✕</button>
    </div>
    <div class="modal-body">
      <iframe id="formIframe" src="about:blank"></iframe>
    </div>
  </div>
</div>
```

**JavaScript:**
```javascript
function closeModals() {
  ['formModal','sequenceModal','archModal'].forEach(id => {
    document.getElementById(id).classList.remove('show');
  });
}
// Close on overlay click
document.querySelectorAll('.modal-overlay').forEach(el => {
  el.addEventListener('click', function(e) {
    if (e.target === this) closeModals();
  });
});
// ESC key closes all modals
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') closeModals();
});

function openFormModal(type) {
  const labels = {saas:'SaaS Intake Form',consulting:'Consulting Intake Form',books:'Books Inquiry Form'};
  const urls = {saas:'/admin/forms/saas-intake.html',consulting:'/admin/forms/consulting-intake.html',books:'/admin/forms/books-intake.html'};
  document.getElementById('formModalTitle').textContent = labels[type];
  document.getElementById('formIframe').src = urls[type];
  document.getElementById('formModal').classList.add('show');
}
```

**Usage in HTML:**
```html
<a href="#" onclick="openFormModal('saas')" class="btn btn-primary">📝 Open Intake Form</a>
```

**Server file structure:** The form HTML files live in `/admin/forms/{product}-intake.html` on the server. Deploy them alongside the dashboard.

### 2. Email Sequence Modal (JSON fetch → styled cards)

Fetches a nurture sequence JSON file from the server and renders each email as a stylized card showing day, subject, body preview, and CTA.

**CSS (add after form modal CSS):**
```css
.sequence-card{background:#0f172a;border:1px solid #334155;border-radius:8px;padding:14px;margin-bottom:12px}
.sequence-card h4{font-size:13px;font-weight:600;color:#00ffcc;margin-bottom:4px}
.sequence-card .seq-day{font-size:11px;color:#667eea;font-weight:600;margin-bottom:2px}
.sequence-card .seq-subject{font-size:13px;color:#e2e8f0;margin-bottom:6px}
.sequence-card .seq-preview{font-size:12px;color:#94a3b8;line-height:1.5;max-height:60px;overflow:hidden}
.sequence-card .seq-cta{font-size:11px;color:#f59e0b;margin-top:6px}
```

**HTML:**
```html
<!-- Sequence Modal -->
<div class="modal-overlay" id="sequenceModal">
  <div class="modal-content">
    <div class="modal-header">
      <h3 id="sequenceModalTitle">Email Sequence</h3>
      <button class="modal-close-btn" onclick="closeModals()">✕</button>
    </div>
    <div class="modal-body" id="sequenceModalBody"></div>
  </div>
</div>
```

**JavaScript:**
```javascript
function openSequenceModal(type) {
  const labels = {saas:'SaaS Nurture (7 emails)',consulting:'Consulting Nurture (5 emails)',books:'Books Nurture (4 emails)'};
  const urls = {saas:'/admin/sequences/saas-nurture.json',consulting:'/admin/sequences/consulting-nurture.json',books:'/admin/sequences/books-nurture.json'};
  document.getElementById('sequenceModalTitle').textContent = labels[type];
  const body = document.getElementById('sequenceModalBody');
  body.innerHTML = '<div style="text-align:center;padding:40px;color:#94a3b8">⏳ Loading...</div>';
  document.getElementById('sequenceModal').classList.add('show');

  fetch(urls[type])
    .then(r => r.json())
    .then(data => {
      const emails = data.emails || data.email_sequences || [];
      if (emails.length === 0) {
        body.innerHTML = '<div style="text-align:center;padding:40px;color:#94a3b8">No emails found</div>';
        return;
      }
      body.innerHTML = emails.map(e =>
        `<div class="sequence-card">
          <div class="seq-day">Day ${e.day || '—'}</div>
          <h4>${escapeHtml(e.subject || e.subject_line || '(No subject)')}</h4>
          <div class="seq-preview">${escapeHtml((e.body || e.body_template || '').slice(0,200))}...</div>
          ${e.cta ? `<div class="seq-cta">📌 ${escapeHtml(e.cta)}</div>` : ''}
        </div>`
      ).join('');
    })
    .catch(err => {
      body.innerHTML = `<div style="text-align:center;padding:40px;color:#ef4444">❌ ${err.message}</div>`;
    });
}
```

**JSON sequence file structure (`/admin/sequences/{product}-nurture.json`):**
```json
{
  "pipeline": "SaaS",
  "email_sequences": [
    {
      "day": 1,
      "subject": "Welcome to MIFECO!",
      "body": "Hi {{name}},\n\nThanks for your interest...",
      "cta": "Schedule your demo"
    }
  ]
}
```

The function handles both `emails` and `email_sequences` array key conventions.

### 3. Architecture Modal (fetch markdown → rendered)

Fetches an ARCHITECTURE.md from the server and renders it with basic markdown-to-HTML conversion. Good for displaying system design docs inline.

**CSS:**
```css
.arch-content{font-size:13px;color:#e2e8f0;line-height:1.7}
.arch-content h2{font-size:18px;color:#00ffcc;margin-top:20px;margin-bottom:10px;border-bottom:1px solid #334155;padding-bottom:6px}
.arch-content h3{font-size:15px;color:#667eea;margin-top:16px;margin-bottom:8px}
.arch-content code{background:#0f172a;padding:1px 5px;border-radius:3px;font-size:12px;color:#f59e0b}
.arch-content pre{background:#0f172a;border:1px solid #334155;border-radius:8px;padding:14px;overflow-x:auto;margin:10px 0;font-size:12px;color:#e2e8f0}
.arch-content table{border-collapse:collapse;width:100%;margin:10px 0;font-size:12px}
.arch-content td,.arch-content th{border:1px solid #334155;padding:6px 10px;text-align:left}
.arch-content th{background:#0f172a;color:#00ffcc;font-weight:600}
.arch-content a{color:#667eea}
```

**HTML:**
```html
<!-- Architecture Modal -->
<div class="modal-overlay" id="archModal">
  <div class="modal-content" style="max-width:900px">
    <div class="modal-header">
      <h3>📐 Architecture</h3>
      <button class="modal-close-btn" onclick="closeModals()">✕</button>
    </div>
    <div class="modal-body" id="archModalBody"></div>
  </div>
</div>
```

**JavaScript:**
```javascript
function openArchitectureModal() {
  const body = document.getElementById('archModalBody');
  body.innerHTML = '<div style="text-align:center;padding:40px;color:#94a3b8">⏳ Loading...</div>';
  document.getElementById('archModal').classList.add('show');
  fetch('/admin/ARCHITECTURE.md')
    .then(r => r.text())
    .then(md => {
      let html = md
        .replace(/```(\w*)\n([\s\S]*?)```/g, '<pre><code>$2</code></pre>')
        .replace(/^### (.+)$/gm, '<h3>$1</h3>')
        .replace(/^## (.+)$/gm, '<h2>$1</h2>')
        .replace(/^# (.+)$/gm, '<h1 style="font-size:20px;color:#00ffcc">$1</h1>')
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.+?)\*/g, '<em>$1</em>')
        .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" target="_blank">$1</a>');
      body.innerHTML = '<div class="arch-content">' + html + '</div>';
    })
    .catch(err => {
      body.innerHTML = `<div style="text-align:center;padding:40px;color:#ef4444">❌ ${err.message}</div>`;
    });
}
```

The markdown converter handles: code blocks, headings (h1-h3), bold, italic, links, tables (basic), lists, and horizontal rules. For a full markdown renderer, consider adding `marked.js` via CDN, but the inline converter keeps zero dependencies.

---

## Infographic Sections on Content Cards

For content command center dashboards, add compact infographic metric sections to content cards. These provide at-a-glance performance estimates and visual progress bars.

### Pattern

Insert a styled `<div>` block before the `.actions` div in each render function:

```html
<div style="margin:8px 0 10px;padding:8px 10px;background:rgba(0,255,204,.04);border-radius:6px;border:1px solid rgba(0,255,204,.08)">
  <div style="display:flex;gap:12px;font-size:10px;flex-wrap:wrap">
    <span style="color:#94a3b8">📈 <strong style="color:#00ffcc">2.4K</strong> est. impressions</span>
    <span style="color:#94a3b8">💬 <strong style="color:#667eea">85</strong> engagements</span>
    <span style="color:#94a3b8">⏰ Best: <strong style="color:#f59e0b">8-10am EST</strong></span>
  </div>
  <div style="margin-top:4px;height:4px;background:#334155;border-radius:2px;overflow:hidden">
    <div style="height:100%;width:68%;background:linear-gradient(90deg,#00ffcc,#667eea);border-radius:2px"></div>
  </div>
</div>
```

### Per-Content-Type Template

**X Posts:** Impressions (2.4K), Engagements (85), Best time (8-10am EST), gradient bar
**Blog Posts:** Dynamic read time (`Math.max(1, Math.round(item.body.split(/\s+/).length / 200))` min), difficulty badge (Beginner/Intermediate/Advanced based on word count), topic from first keyword, multi-color bar
**LinkedIn Posts:** Reach (3.1K), Reactions (124), Comments (18), Content type tag, gradient bar

For blog posts, calculate dynamically:
```javascript
const wordCount = item.body.split(/\s+/).length;
const readTime = Math.max(1, Math.round(wordCount / 200));
const difficulty = wordCount > 500 ? 'Advanced' : wordCount > 200 ? 'Intermediate' : 'Beginner';
```

---

## Book Catalog Maintenance

When a pipeline dashboard has an embedded book catalog that needs updating:

### Correcting Wrong Titles

1. Find the `books:` array in the pipeline data JS object (e.g., `booksPipeline.books`)
2. Replace each wrong title string with the correct one
3. Update prices if needed
4. Validate JSON integrity with `python3 -c "import json; json.load(open('file.html'))" - not applicable for embedded JS — just visually verify the array syntax

### Adding Missing Books

Append new entries to the array:

```javascript
books: [
  { title:'No Blue Sky: Built from Dust',            price:9.99 },
  { title:'No Blue Sky: The Oxygen Gamble',          price:11.99 },
  // ... existing books ...
  { title:'AI That Works for Small Business',        price:19.99 },   // 🆕
  { title:'No Blue Sky Box Set (all 5 vols)',        price:49.99 },   // 🆕
  { title:'The MIFECO AI Playbook',                  price:9.99 }     // 🆕
]
```

---

## Sidebar Navigation Cleanup

When a pipeline dashboard has duplicate sidebar links (one set that scrolls to sections, another set that shows alerts), consolidate to a single clean nav:

**Before (problematic):**
```html
<nav class="sidebar-nav">
  <a href="#intake-forms">📝 Intake Forms</a>
  <a href="#email-sequences">✉️ Email Sequences</a>
</nav>
<!-- ... later in sidebar-footer ... -->
<nav class="sidebar-footer">
  <a href="#" onclick="alert('Forms available locally')">📝 Intake Forms</a>  ← DUPLICATE
  <a href="#" onclick="alert('Sequences available locally')">✉️ Email Sequences</a>  ← DUPLICATE
</nav>
```

**After (clean):**
```html
<nav class="sidebar-nav">
  <a href="#overview">📊 Overview</a>
  <a href="#saas">☁️ SaaS Pipeline</a>
  <a href="#consulting">💼 Consulting Pipeline</a>
  <a href="#books">📚 Books Pipeline</a>
  <a href="#intake-forms">📝 Intake Forms</a>       ← scrolls to section
  <a href="#email-sequences">✉️ Email Sequences</a>   ← scrolls to section
  <hr><!-- separator -->
  <a href="content-command-center.html">📊 Content Command Center</a>
  <a href="#" onclick="openArchitectureModal()">📐 View Architecture</a>
</nav>
<nav class="sidebar-footer">
  <a href="?logout=1">🚪 Logout</a>
</nav>
```

**Rules:**
- Scroll-to-section links (`href="#section"`) go in `sidebar-nav`
- External dashboard links (Hermes Dashboard, Content Command Center) also go in `sidebar-nav` — NOT in `sidebar-footer` — so they appear in the mobile hamburger menu
- Only Logout stays in `sidebar-footer` (it's small and fits)
- Never have two links pointing to the same function on the same page
- Replace all `onclick="alert(...)` with either modals or proper href navigation

## Mobile Responsive Sidebar

When a dashboard uses a hamburger menu on mobile (sidebar slides in from the left), anything in `.sidebar-footer` is typically **below the scroll fold** — users don't know to scroll down in the sidebar. This means:

- **Links in `.sidebar-footer` are invisible on mobile** even when the hamburger menu opens
- **Fix:** Promote external dashboard links (🤖 Hermes Dashboard, 📊 Content Command Center) into the main `.sidebar-nav` above the footer, separated by a `<hr>` line
- **Good pattern:**
  ```html
  <nav class="sidebar-nav">
    <a href="#overview">📊 Overview</a>
    <a href="#saas">☁️ SaaS Pipeline</a>
    <!-- ... main nav links ... -->
    <hr style="border:none;border-top:1px solid #334155;margin:8px 20px;">
    <a href="hermes-dashboard.html" onclick="closeSidebar()">🤖 Hermes Dashboard</a>
    <a href="content-command-center.html" onclick="closeSidebar()">📊 Content Command Center</a>
  </nav>
  <div class="sidebar-footer">
    <a href="?logout=1">🚪 Logout</a>
  </div>
  ```
- **Always add `onclick="closeSidebar()"`** to each nav link so mobile hamburger autocloses on tap
- Verify on real mobile: open the hamburger, check all links are visible without scrolling
- The sidebar must have `overflow-y: auto` (already present) so the full content is scrollable if needed

---

## SFTP Deployment via Python paramiko

When `sshpass` or `pexpect` isn't available, use Python's `paramiko` library for password-based SFTP deployment:

```python
import paramiko
import os

host = "your-host.com"
user = "your-username"
password = "your-password"

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(host, username=user, password=password, look_for_keys=False)
sftp = ssh.open_sftp()

# Upload a file
local_path = "/local/path/to/file.html"
remote_path = "/remote/path/to/file.html"
sftp.put(local_path, remote_path)

# Upload multiple files
files = ["pipeline-dashboard.html", "content-command-center.html", "index.php"]
for f in files:
    sftp.put(os.path.join(local_dir, f), os.path.join(remote_dir, f))

# Create remote directories
for d in ["/forms", "/sequences"]:
    try:
        sftp.stat(remote_dir + d)
    except:
        sftp.mkdir(remote_dir + d)

sftp.close()
ssh.close()
```

**Usage pattern:** Wrap in `execute_code` or run via `terminal()` with `python3 -c`.

**Fallback when paramiko isn't installed:**
```bash
pip3 install paramiko
```

## Pitfalls

| Pitfall | Why | How to Avoid |
|---------|-----|--------------|
| **`--delete` wipes WordPress** | Rsync with `--delete` removes anything not in the source. WordPress lives in the same root. | Never use `--delete` on a WordPress root. Target a subdirectory like `admin/`. |
| **PHP sessions not persisting** | Shared hosting may use file-based sessions in a temp dir that gets cleaned | Set `session.gc_maxlifetime` in .htaccess or php.ini to 7200+ |
| **.htaccess rules blocking webhook** | Rewrite rules meant for the password gate may intercept webhook.php | Add explicit `RewriteCond` to allow webhook.php through before the auth rules |
| **Webhook accessible without password** | Password gate is session-based, webhook is intentionally public | The webhook uses an in-payload secret instead of session auth — this is by design but make sure the secret is strong |
| **Dashboard links broken in subdirectory** | Relative paths like `../forms/` don't resolve from `/admin/` | Use hash-based navigation (`href="#section"`) or absolute paths. Alert-based fallbacks work for local-only files. |
| **Approval state lost on page refresh** | State only in memory, not persisted | Use `localStorage` with a versioned key. On page load, `loadState()` restores all approve/sent/deleted states. |
| **Send triggered without approval** | The send button is directly accessible on pending items | Hide the send button until the item is approved. Only the "Approve" button shows on pending items. The "Send Now" button only appears after `isApproved()` returns true. |
| **Double-escaped JSON in body content** | `patch` tool re-escapes text that already contains `\n` escape sequences in JSON string values | When a file has JSON with embedded `\n` (newline escape sequences), write the entire file fresh instead of patching individual strings within body fields |
