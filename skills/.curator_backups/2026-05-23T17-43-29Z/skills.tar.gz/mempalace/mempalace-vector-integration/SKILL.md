---
name: mempalace-vector-integration
title: MemPalace Vector Integration
description: Semantic vector memory using ONNX Runtime + ChromaDB — 384-dim embeddings, ~3ms per query after cache warm
tags: [mempalace, vector, chromadb, onnx, embeddings, semantic-search]
required_commands: []
required_environment_variables: []
setup_needed: false
---

# MemPalace Vector Integration

ONNX Runtime (embedding inference) + ChromaDB (vector store) for MemPalace's semantic memory layer.

## System Architecture

Text => [all-MiniLM-L6-v2 ONNX Model] => 384-dim vector => [ChromaDB (HNSW)] => Search Results
(~3ms per text cached) (~1ms per query)

## Location

- Module: `~/.hermes/mempalace-vector/vector_memory.py`
- Model cache: `~/.hermes/mempalace-vector/models/`
- ChromaDB storage: `~/.hermes/mempalace-vector/collections/`

## Quick Usage

```python
from vector_memory import VectorMemory

vm = VectorMemory()

# Add a memory
vm.add("mem_001", "MIFECO provides AI consulting for small businesses", {"tag": "consulting"})

# Semantic search
results = vm.search("AI readiness assessment", k=5)
for r in results:
    print(f"[{r['id']}] score={r['score']:.4f}: {r['metadata']['text'][:80]}")

# Update / Delete
vm.update("mem_001", "Updated text", {"tag": "consulting"})
vm.delete("mem_001")

# Count
print(f"{vm.count()} memories")
```

## Multiple Collections

```python
books = VectorMemory(collection_name="books")
leads = VectorMemory(collection_name="leads")
```

## CLI Usage

```bash
cd ~/.hermes/mempalace-vector
python vector_memory.py add my_id "Text content here" --tag my_tag
python vector_memory.py search "query text" --k 10
python vector_memory.py get my_id
python vector_memory.py delete my_id
python vector_memory.py count
```

## Performance

| Operation | Time |
|-----------|:----:|
| First model load (cold) | ~4s |
| Embedding (cached) | ~3ms |
| Search (10k corpus) | ~2ms |
| ChromaDB write | <1ms |

## Technical Details

- **Embedding model**: sentence-transformers/all-MiniLM-L6-v2 (384-dim, 88MB ONNX)
- **Vector store**: ChromaDB 1.5.9, HNSW indexing (cosine distance)
- **Inference**: ONNX Runtime via optimum.onnxruntime
- **Fallback**: SentenceTransformer (PyTorch) if optimum not installed