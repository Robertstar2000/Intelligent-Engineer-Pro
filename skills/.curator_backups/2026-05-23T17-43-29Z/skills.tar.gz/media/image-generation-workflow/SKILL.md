---
name: image-generation-workflow
description: Workflow for generating AI images in Hermes
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [image, ai, generation, workflow]
    homepage: https://github.com/NousResearch/hermes-agent
---

# AI Image Generation Workflow

This skill provides approaches for generating AI images in Hermes.

## Methods

### 1. Dedicated Image Generation Tool
Use `image_gen` when available. Enable via `hermes tools enable image_gen`.

### 2. Browser Automation
Use browser tools to access web-based AI image generators like Bing Image Creator or Clipdrop.

## Best Practices

- Start with dedicated tool when available
- Use detailed prompts with style references
- Include aspect ratio specifications for book covers
- Add quality descriptors like "4k, high detail, cinematic lighting"
- Always verify generated images before sending

## Example: Generate Book Covers
```python
prompt = "Epic sci-fi book cover, futuristic cityscape with towering neon-lit skyscrapers, flying vehicles, holographic advertisements, dystopian atmosphere, Earth Central AI controlling everything, dark moody lighting, cinematic, high detail, 4k --ar 2:3"

# Use image_gen if available, otherwise browser automation
if image_gen_available():
    generate_with_image_gen(prompt)
else:
    generate_with_bing_image_creator(prompt)
```

## Book Cover Generation: Two-Pass Workflow (Battle-Tested)

**CRITICAL LESSON:** Never attempt to generate images AND add typography in a single script. External APIs (Pollinations, OpenRouter) are unreliable with timeouts and corrupted responses. Use a **two-pass approach**:

### Pass 1: Generate Raw Images (NO text, NO overlays)
```python
import requests, urllib.parse, time
from PIL import Image
from io import BytesIO

def gen_raw(path, prompt, seed):
    url = f'https://image.pollinations.ai/prompt/{urllib.parse.quote(prompt)}?width=1024&height=1536&nologo=true&private=true&enhance=true&seed={seed}'
    for attempt in range(3):
        try:
            r = requests.get(url, timeout=120)
            if r.status_code == 200 and len(r.content) > 50000:
                with open(path, 'wb') as f:
                    f.write(r.content)
                # CRITICAL: Verify PIL can actually open it before trusting it
                img = Image.open(path)
                return True
        except:
            time.sleep(5)
    return False
```

### Pass 2: Apply Typography Separately (on verified files only)
```python
def apply_cover_text(raw_path, final_path, title, author='BOB MILLS'):
    img = Image.open(raw_path).convert('RGBA')
    w, h = img.size
    overlay = Image.new('RGBA', img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(overlay)
    
    # Semi-transparent black boxes for readability
    words = title.upper().split()
    f_title = ImageFont.truetype('/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf', 40)
    f_author = ImageFont.truetype('/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf', 21)
    d.rectangle([250, 100, 774, 100 + (len(words)*70)], fill=(0,0,0,140))
    d.rectangle([350, h-200, 674, h-130], fill=(0,0,0,140))
    
    img = Image.alpha_composite(img, overlay)
    draw = ImageDraw.Draw(img)
    
    # Draw stacked title (one word per line)
    curr_y = 120
    for word in words:
        bbox = draw.textbbox((0, 0), word, font=f_title)
        draw.text(((w-(bbox[2]-bbox[0]))/2, curr_y), word, font=f_title, fill='white')
        curr_y += 70
    
    # Draw author at bottom
    bbox_a = draw.textbbox((0, 0), author.upper(), font=f_author)
    draw.text(((w-(bbox_a[2]-bbox_a[0]))/2, h-175), author.upper(), font=f_author, fill='white')
    
    img.convert('RGB').save(final_path)
```

### Reliability Rules for Cover Generation
1. **Always generate raw images first** - Never mix API calls with image processing in one script
2. **Validate file size** - Pollinations returns tiny corrupted files (~600 bytes) on failure; reject anything under 50KB
3. **Verify with PIL** - Always call `Image.open()` after download to catch non-image error responses
4. **Use unique seeds per image** - Pollinations caches aggressively; add `seed={int(time.time())+offset}`
5. **Generate one cover at a time** - Batch generation of 3+ covers times out
6. **Never overwrite raw masters** - Save raw backgrounds separately; typography is always a second pass
7. **Use `background=true` + `notify_on_complete`** for long-running generation tasks
8. **Keep raw copies** - Always save `*_Raw.png` and `*_Final.png` as separate files