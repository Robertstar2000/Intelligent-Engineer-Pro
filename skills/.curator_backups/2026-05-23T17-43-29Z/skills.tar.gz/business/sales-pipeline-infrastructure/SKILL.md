---
name: sales-pipeline-infrastructure
description: Build a complete lead-to-revenue pipeline automation system for one or more product lines — intake forms, data trackers, email nurture sequences, LinkedIn discovery, social media content generation, content deployment dashboard with SEND/DELETE, unified cross-product pipeline, and cron-based orchestration.
version: 1.6.0
author: Hermes Agent
tags:
  - sales
  - pipeline
  - lead-generation
  - email-nurture
  - dashboard
  - automation
  - agentmail
related_skills:
  - ceo-agent-orchestrator
  - virtual-consulting
  - complex-task-orchestration
  - book-marketing-launch
  - pipeline-dedup-discovery
---

# Multi-Product Sales Pipeline Infrastructure

## Trigger Conditions

Use this skill when building or modifying lead-to-revenue pipeline systems, dashboards, enrichment engines, cron orchestration, or content deployment views. Covers setup from scratch AND ongoing operations.

## Architecture

```
LEAD SOURCE → CAPTURE → SCORE → NURTURE → CONVERT → ONBOARD
AgentMail inboxes (1 per product line)
9 Operation Pipelines: lead-gen, promo-gen, book-ideation, book-pub, saas-ideation, saas-deploy, saas-sales, consult-ideation, consult-sales
```

## Pipeline Operations Data Layer (Shared State JSON)

When syncing Pipeline Ops numbers with Content CC, build a **pipeline-state.json** at `pipeline-engine/data/pipeline-state.json` as the single source of truth. Copy into `dashboard/` for HTTP serving (server blocks directory traversal). This is a display-oriented summary with `monthlyTarget` (not daily), `cronJob`/`cronSchedule` references, `skills` arrays, `contentCCViewer` field, and `contentSummary` object.

**Key differences from per-pipeline JSON files:** pipeline-state.json uses monthlyTarget (not daily), includes cron job mapping, skills references, and contentCCViewer cross-reference. Both dashboards load it via `fetch('pipeline-state.json')` on page load.

Create a master sync runner at `pipeline-engine/scripts/run-all-pipelines.sh` that runs data sync and copies state to dashboard. Add a cron job at 8:15 AM daily (15 min after main orchestrator).

**Monthly vs Daily conversion:** When user requests monthly targets, convert daily × 30, rename key `dailyTarget`→`monthlyTarget`, relabel "Daily Target"→"Monthly Target".

**Cron job mapping:** Each pipeline object has `cronJob` (name) and `cronSchedule` (cron expression). Display in card footer.

**Pipeline skills reference:** Each pipeline has a `skills` array. Display as ⚡ tag chips in card and flow modal for task delegation context.

## Key Files

```
pipeline-engine/
├── data/
│   ├── pipeline-state.json       ← Shared source of truth (ALL pipelines)
│   ├── pipeline-{product}.json   ← Per-product pipeline trackers (Books/SaaS/Consulting)
│   ├── unified-pipeline.json     ← Optional cross-product view
│   ├── leads-registry.json       ← Canonical lead list for dedup
│   ├── dedup-check.py            ← CLI dedup tool
│   ├── enrichment-engine.py      ← Stale detection
│   ├── content-generator.py      ← Social/blog post generation
│   ├── social-content-*.json     ← Generated posts per product
│   ├── linkedin-outreach-messages.json
│   ├── linkedin-automation.sh
│   ├── daily-pipeline-report.md  ← Orchestrator output
│   └── outreach/                 ← Generated emails/SVGs
├── scripts/
│   ├── pipeline-sync.py          ← Reads real data, updates pipeline-state.json
│   ├── pipeline_data_api.py      ← POST API: advance-lead, mock-inbox, clear-mock-inbox
│   ├── daily-pipeline-analysis.py ← Full 7-step orchestrator analysis (reusable)
│   └── run-all-pipelines.sh      ← Master cron runner
├── sequences/{product}-nurture.json
├── forms/{product}-intake.html
├── data/
│   ├── mock-inbox.json           ← Test-mode sent emails (created by pipeline_data_api.py)
│   └── ...
└── dashboard/
    ├── pipeline-dashboard.html   ← Pipeline Command Center
    ├── outreach-dashboard.html   ← Send interface (API-powered, mode toggle, mock inbox viewer)
    ├── pipeline-state.json        ← Copy of state for HTTP serving
    └── flows/*.svg               ← Pipeline flow diagrams
```

## 4-Panel MIFECO Dashboard Template

The dashboard at `pipeline-engine/dashboard/pipeline-dashboard.html` follows a dark-themed (#0f172a bg, #00ffcc accent) multi-panel layout with fixed sidebar:

1. **📚 Books Catalog** — Auto-adapting grid of book cards with status badges (ideation/written/edited/packaged/published)
2. **☁️ SaaS Applications** — Cards with GitHub/prod/local links, online/offline status dots
3. **💼 Virtual Consulting** — Tier pricing grid, pipeline flow modal
4. **📊 Lead & Promotion** — Cross-pipeline stats, outreach engine status, nurture sequence status
5. **⚙️ Pipeline Operations Center** — 9 pipeline cards with run/pause/stop controls, progress bars, monthly thresholds, cron job mapping, skills display, and flow diagram modal
6. **🩺 Pipeline Health** — Per-pipeline operational status cards

### Outreach Dashboard (Send Interface)

At `dashboard/outreach-dashboard.html`: Enriched lead cards organized by pipeline (Books/SaaS/Consulting) with:

- **Mode toggle** — 🧪 Test mode (emails go to mock inbox, viewable inline) / 🚀 Production mode (emails sent via WordPress REST → DreamHost SMTP)
- **API-powered sends** — Clicking "Send" calls `POST /api/advance-lead`, advancing the lead's stage in the pipeline JSON from "Lead Inbox" → "Contacted"
- **Mock inbox panel** — Visible in test mode, shows all sent emails with body previews
- **Email enrichment gate** — Only leads with valid emails get Send buttons
- **Filter bar** — By pipeline (Books/SaaS/Consulting) or readiness (Ready / Needs Enrichment)

**Note:** The spec-described `dashboard/content-command-center.html` (6 viewer tabs) is NOT deployed. The outreach dashboard serves as the primary send interface.

### Dashboard Data Loading

Both dashboards load `pipeline-state.json` dynamically on page load. Pipeline Ops overlays data on static defaults. Content CC updates sidebar stats from `contentSummary`. The JSON file must be in the dashboard directory.

## Cron Orchestration

- **8:00 AM** — Pipeline Orchestrator (dedup + data reading + stage calc + report)
- **8:00 AM** — CEO Agent (business assessment + task assignment)
- **8:15 AM** — Pipeline Ops Sync (runs sync script, copies state to dashboard)
- **8:30 AM** — Promotion Generation (content check + state update)
- **8:30 AM** — Dashboard Sync (deploy to mifeco.com)
- **Sunday 8:00 AM** — Backlink Acquisition (weekly)

All cron jobs are read-only. They report what needs doing; humans/CEO agent make changes.

## Process Overview

1. **Define architecture** (ARCHITECTURE.md with stages, inboxes, products)
2. **Create per-product pipeline trackers** (JSON with stages/leads/ICP scores)
3. **Set up lead registry & dedup** (leads-registry.json + dedup-check.py)
4. **Build intake forms** (POST to AgentMail)
5. **Create nurture sequences** (SaaS 7, Consulting 5, Books 4)
6. **Build dashboards** (Pipeline CC + Content CC)
7. **Set up cron orchestration** (report → state → sync cycle)
8. **LinkedIn discovery** (browser guide + automated messages)
9. **Social media content** (per-platform per-product posts)
10. **Enrichment operations** (lead verification, scoring, outreach generation)
11. **Pipeline date resets** (fresh start when needed)
12. **Product changes** (multi-file update pattern: JSON → Sequence → Dashboard → Content CC)
13. **Unify pipelines** (optional cross-product view)

## Pitfalls

- **Shared state file must be in dashboard/ directory** — HTTP server blocks directory traversal above serving root
- **Both dashboards must load pipeline-state.json** — Pipeline Ops for pipeline counts, Content CC for sidebar stats
- **Monthly targets not daily** — Users prefer monthly ×30 scaling
- **No automated email sending** — Every email needs individual human approval via the Send button
- **Leads don't advance when "sent" via dashboard alone** — The outreach dashboard's localStorage-only send doesn't update the pipeline JSON files. You MUST wire up a server-side API (`pipeline_data_api.py`) that:
  1. Receives `POST /api/advance-lead` with pipeline, lead_name, mode
  2. Updates the lead's `current_stage` from 1→2 in the appropriate `pipeline-{product}.json` file
  3. In test mode: writes to `mock-inbox.json` for review
  4. In production mode: calls the WordPress REST endpoint for real sending
  Without this, leads stay at "Lead Inbox" forever regardless of how many Send buttons are clicked
- **Registry format variance** — May use aggregate counts or individual entries; handle both
- **JSON patch escape issues** — Write files fresh when body contains escaped newlines
- **Pipeline data and dashboard arrays must stay in sync** — Always update both
- **Content Command Center may not be deployed** — The spec-defined `content-command-center.html` may not exist. Check first: if absent, use/update `outreach-dashboard.html` which has the mode toggle and mock inbox viewer built-in
- **Date format variance between pipelines** — Books/SaaS use full ISO timestamps (`2026-05-07T14:00:39Z`) while Consulting uses date-only strings (`2026-05-07`). Any script that calculates days-in-stage must handle both formats. Use `datetime.fromisoformat()` for ISO and `datetime.strptime(..., '%Y-%m-%d')` for date-only. The reusable `scripts/daily-pipeline-analysis.py` handles this automatically.
- **Enrichment engine ignores nested `pipeline.leads` structure** — `enrichment-engine.py --report` calls `data.get("leads", ...)` on each pipeline JSON file, but the actual nesting is `data["pipeline"]["leads"]`. This means `--report` only examines 1 lead total — not all leads. For accurate per-lead enrichment status, read the pipeline JSON directly and check each lead's `enriched_at` / `verification_status` / `contact_email` fields. The `--report` mode is only useful for its stale-detection heuristic on the first matched lead.
- **Orchestrator script available as reusable tool** — The full 7-step analysis (days-in-stage, blockers, nurture health, email queue, projection, registry integrity) is available as `scripts/daily-pipeline-analysis.py`. Run it from the pipeline-engine/ directory with `python3 scripts/daily-pipeline-analysis.py` to get the full report on stdout. Redirect to `data/daily-pipeline-report.md` to save.