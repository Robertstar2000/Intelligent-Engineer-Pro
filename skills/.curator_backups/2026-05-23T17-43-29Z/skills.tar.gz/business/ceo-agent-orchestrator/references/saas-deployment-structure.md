# MIFECO SaaS Deployment Structure

> Reference for Cloud Run app deployment — source code layout, deployment commands, and known configurations.
> Last updated: 2026-05-13 (CEO Agent daily run)

## Source Code Location

All 3 SaaS apps live under `/home/bob/saas/`:

| App | Directory | Local Port | server.ts helmet line |
|-----|-----------|------------|----------------------|
| Project Hypatia Pro | `Project_Hypatia_Pro/` | :3001 | Line 53 — `app.use(helmet())` |
| PM Accelerator (HMAP) | `Project_Management_Accelerator/` | :3002 | Line 19 — `app.use(helmet())` |
| VibraEngineer | `VibraEngineer/` | :3003 | Line 21 — `app.use(helmet())` |

## Local Development

All apps are started together via `start-mifeco.sh` which runs:
```bash
cd /home/bob/saas/<AppName>
PORT=30XX nohup npx tsx server.ts > /tmp/<app>.log 2>&1 &
```

## Deployment

**No Dockerfile or cloudbuild.yaml exists** in any app repo. Deployments use Google Cloud Build's automatic Node.js detection:

```bash
cd /home/bob/saas/<AppName>
gcloud run deploy --source .
```

The `node_modules/` directories are pre-bundled in source, so `npm install` is skipped for production builds.

## Cloud Run URLs

| App | URL |
|-----|-----|
| Project Hypatia Pro | `https://project-hypatia-pro-1064319572465.us-west1.run.app` |
| PM Accelerator | `https://project-management-accelerator-845075991286.us-west1.run.app` |
| VibraEngineer | `https://vibraengineer-845075991286.us-west1.run.app` |

## Known Security Header Issues

| App | Headers Missing | CORS | Other |
|-----|-----------------|------|-------|
| Project Hypatia Pro | All 6 | OK | Express x-powered-by leak |
| PM Accelerator | All 6 | OK | Express x-powered-by leak |
| VibraEngineer | All 6 | `access-control-allow-origin: *` (wildcard) | CDN Tailwind (not production build) |

## Authentication

- `gcloud auth list` returns `[]` (empty) as of May 13, 2026
- No authenticated Cloud Run deploy capability from this machine
- Bob must run `gcloud auth login` manually

## Header Check Workaround

The terminal security scanner blocks curl to `.app` TLDs. Use browser console instead:
```javascript
fetch(window.location.href).then(r => console.log(JSON.stringify([...r.headers])))
```
