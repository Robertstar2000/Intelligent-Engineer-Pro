---
name: manuscript-creation
description: >-
  A pipeline for generating new science fiction and fantasy books with sci-fi
  overtones. The skill merges concepts from random best-selling books, creates
  colorful characters, outlines 36-44 chapters, writes each chapter using
  best-selling author techniques, and edits the manuscript for flow, grammar,
  and formatting, producing a final .md file.
version: 1.0.0
author: Hermes Agent
category: creative
tags: [manuscript, writing, sci-fi, fantasy, pipeline, creation]
related_skills: [novel-writing-workflow, manuscript-preparation-and-delivery, writing-plans]
---
# Manuscript Creation Skill

## Purpose
This skill provides an end-to-end pipeline to generate a original science
fiction/fantasy manuscript with sci-fi overtones, from concept to polished
Markdown file, using a combination of idea generation, character development,
chapter outlining, guided writing, and editing.

## When to Use
- When you need a fresh book idea in the sci-fi/fantasy genre.
- To produce a draft manuscript that can be further refined or delivered.
- As a starting point for a novel-writing project.

## Prerequisites
- Access to writing-related skills (e.g., `novel-writing-workflow`,
  `writing-plans`, `manuscript-preparation-and-delivery`).
- Ability to call other skills via `skill_view` or delegate tasks if needed.
- Basic familiarity with Markdown formatting.

## Implementation

This skill provides an executable pipeline that generates a complete manuscript. When invoked, it will:

### 1. Gather Inspiration from Best-Selling Books
- Extract core concepts from knowledge of recent best-selling sci-fi/fantasy themes
- Identify key elements from works like The Martian, Project Hail Mary, The Expanse, Artemis, and Three-Body Problem
- Merge into a cohesive concept involving specified agencies (NASA, CNSA, SpaceX, etc.)

### 2. Develop Character Roster
- Create 6-8 diverse characters with roles, traits, and arcs
- **Use randomly selected names from the top 50 most common first names (SSA data)** — this is MANDATORY, not optional. Avoid any ethnically-marked, internationally-diverse, or "AI-sounding" names (Elena, Diego, Mei-Lin, Rajiv, Jean-Luc, Aisha, Ana, Kenji, etc.). Pick from James, Robert, John, Michael, David, William, Richard, Joseph, Thomas, Christopher, Charles, Daniel, Matthew, Anthony, Mark, Steven, Paul, Andrew, Joshua, Kenneth, Kevin, Brian, George, Timothy, Ronald, Edward, Jason, Jeffrey, Ryan, Jacob, Gary, Nicholas, Eric, Jonathan, Stephen, Larry, Justin, Scott, Brandon, Benjamin, Samuel, Raymond, Gregory, Frank, Alexander, Patrick, Jack, Dennis, Jerry (male) and Mary, Patricia, Jennifer, Linda, Barbara, Elizabeth, Susan, Jessica, Sarah, Karen, Lisa, Nancy, Betty, Margaret, Sandra, Ashley, Dorothy, Kimberly, Emily, Donna, Michelle, Carol, Amanda, Melissa, Deborah, Stephanie, Rebecca, Sharon, Laura, Cynthia, Kathleen, Amy, Angela, Shirley, Anna, Brenda, Pamela, Emma, Nicole, Helen, Samantha, Katherine, Christine, Debra, Rachel, Carolyn, Janet, Catherine, Maria, Heather (female).
- Ensure representation of international collaboration
- Ensure diversity in background, gender, and cultural representation

### 3. Outline Chapter Structure
- Create 40 chapter outline (midpoint of 36-44 range)
- Each chapter has title and 1-2 sentence summary
- Logical narrative arc from initial landing to established base

### 4. Write Manuscript Chapter-by-Chapter (Parallel Batches)

For 30+ chapter novels, use **parallel batch writing** instead of sequential (see "Production Approach" below). Each batch subagent writes 10 complete chapters.

- **Write in bestselling author style** (e.g., Andy Weir's technical precision mixed with James S.A. Corey's character depth)
- **Humanize all content** — include personal reflections, emotional beats, and physiological reactions alongside technical details
- **Apply the humanizer skill to all output** — before delivering any chapter, load the `humanizer` skill and run its 29 pattern checks. Strip all AI-isms, filler, and LLM-sounding language. Ensure real voice, variable rhythm, opinions where they fit. This is mandatory for every chapter.
- Target **1,000-1,400 words per chapter** (~44,000-50,000 words total for 40 chapters) to ensure final paperback book of 170-200 pages at 6×9in
- Maintain consistent character voices across parallel batches by sharing character docs and sample chapters with every subagent
- Verify character voice consistency after all batches return — spot-check one chapter from each batch per major character

### 5. Edit and Polish
- **Sequential flow edit**: Read the manuscript sequentially, ensuring smooth transitions between chapters, consistent pacing, and logical plot progression. Trim or expand sections as needed.
- **Reader engagement check**: Every chapter, every transition, every scene must be interesting, exciting, and engaging to readers. If any section reads as filler or flat exposition, rewrite it. Each added paragraph must earn its place — advancing story, revealing character, building tension, or creating emotional resonance.
- **Grammar & Mechanics**: Check for spelling, punctuation, and grammatical errors. Apply consistent style (e.g., Oxford comma, dialogue formatting).
- **Markdown Formatting**: Verify Markdown syntax (heading levels, list formatting, emphasis) and ensure the document renders correctly.
- **Consistency Check**: Run a comprehensive check on character names, terminology, world-building details, and timeline consistency.
- **Read-Aloud Edit**: Simulate reading aloud to catch awkward phrasing, repetition, and rhythm issues.
- **Final Proofread**: Line-by-line edit to catch any remaining errors before final output.

### 6. Output Final Manuscript
- Save as polished .md file
- Ready for delivery

## "Best Selling Author Quality" — Concrete Requirements

The user explicitly requires **best-selling author quality** prose. This means:

### Tone & Style
- **Show, don't tell**: Every technical concept must emerge through character action, failure, and discovery, not exposition
- **Character interiority**: Include sensory details (smell, sound, physical sensation), emotional beats (fear, hope, exhaustion), and physiological responses alongside technical problem-solving
- **Dialogue that reveals character**: Every conversation should advance both plot AND character relationships
- **Pacing**: Alternate high-tension scenes with quieter character moments — never let technical problem-solving go on for more than 2 pages without a human beat

### Reference Authors (per user preference)
- Andy Weir's technical precision and problem-solving focus (The Martian, Project Hail Mary)
- James S.A. Corey's character depth and interpersonal stakes (The Expanse)
- The balance: every engineering challenge must have a human cost, and every human moment must respect the technical reality

### Word-Level Craft
- Avoid cliché descriptions ("the vastness of space," "the silence was deafening")
- Use domain-specific vocabulary naturally (engineers use acronyms, scientists use precise terminology)
- Keep sentences varied in length — short for tension, longer for reflection

## Production Approach

### Parallel Batch Writing (Preferred for 30+ Chapters)

For novels of 30+ chapters, DO NOT write chapters one-by-one. Instead:

1. **Create planning documents first**: Write concept, character roster, and 40-chapter outline as separate files in the book directory
2. **Write chapters in parallel batches** via `delegate_task`:
   - Batch 1: Chapters 1-10 (Part I — Setup)
   - Batch 2: Chapters 11-20 (Part II — Escalation)
   - Batch 3: Chapters 21-30 (Part III — Climax/Gamble)
   - Batch 4: Chapters 31-40 (Part IV — Resolution/New Normal)
3. **Each batch subagent receives**: the outline, character doc, and existing chapter samples for tone reference
4. **Each batch subagent writes**: 10 fully complete chapters of 1,000-1,400 words each (not 1,200-1,500 — the lower bound is tighter to ensure total lands at ~45k words)
5. **After all batches return**: combine into single manuscript, add front/back matter

### 4-Part Narrative Framework

Structure your 40 chapters into the following 4-part arc. Each part is 10 chapters:

| Part | Theme | Chapters | Narrative Function |
|------|-------|:--------:|--------------------|
| I | The Numbers Don't Lie | 1-10 | **Setup** — introduce problem, characters, stakes; end with first attempt at solution |
| II | Things Fall Apart | 11-20 | **Escalation** — initial solution fails, complications multiply, team fractures under pressure |
| III | The Gamble | 21-30 | **Climax** — last-ditch effort, everything on the line, breakthrough achieved but at cost |
| IV | The New Normal | 31-40 | **Resolution** — aftermath, reflection, transformation, looking toward future |

### Character Consistency Across Parallel Batches

When delegating chapters to multiple subagents, each batch subagent receives:
- The full character roster with personality notes, speech patterns, and relationship dynamics
- A sample chapter from an already-written batch for tone/voice reference
- The outline for their specific 10-chapter range

After all batches return, do a **character voice consistency check** across the whole manuscript — verify each major character sounds the same in all 4 parts.

### Front Matter for Manuscript Files

Every compiled manuscript must include:
1. **Title page** — book title, subtitle, series name, author name
2. **Copyright page** — copyright notice, rights reserved, "Review proof — not for distribution"
3. **Table of Contents** — linked list of all chapter titles
4. **All chapters** — in order, each starting with `## Chapter N — Title`
5. **About the Author** — back matter bio
6. **About the Series** — optional, listing other books in the series

### Verification Checklist
- [ ] Core story concept defined in a dedicated concept document
- [ ] Character list includes 6–8 distinct individuals with role, background, arc, and voice notes
- [ ] Chapter outline contains 36–44 entries, each with title and 1-2 sentence summary
- [ ] Writing done in parallel batches of 10 chapters each via delegate_task
- [ ] Each chapter is 1,000-1,400 words
- [ ] Character voices consistent across all batches (spot-check at least one chapter from each batch)
- [ ] Manuscript has undergone flow, grammar, and formatting edits
- [ ] Total word count 44,000-50,000 for a ~180-200 page book at 6×9in
- [ ] Front/back matter present (title, copyright, TOC, about author)
- [ ] Final output is a valid Markdown `.md` file

## Example Usage

This skill is typically invoked as part of a larger workflow. A typical session:

```
# 1. Create planning documents
hermes skill run manuscript-creation (concept + characters + outline)

# 2. Write chapters in parallel batches
delegate_task(generate_chapters_01_10, generate_chapters_11_20, ...)

# 3. Assemble and generate PDF
manuscript-preparation-and-delivery (compile → format → PDF)
```

## Notes
- The skill relies on other writing and manuscript skills for the actual
  text generation and editing steps; ensure those are available and
  functional.
- Adjust chapter length targets and number of chapters based on the
  desired final book length.
- For best results, provide any specific style references (e.g., “write
  in the style of Brandon Sanderson” or “like a Neal Stephenson novel”)
  when invoking the writing sub‑skills.