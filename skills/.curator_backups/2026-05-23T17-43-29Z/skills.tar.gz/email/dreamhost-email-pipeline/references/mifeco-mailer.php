<?php
/**
 * Plugin Name: MIFECO Mailer
 * Description: Email sending endpoint for MIFECO content command center.
 * Creates REST endpoint at /wp-json/mifeco/v1/send-email
 * Requires subject to contain [SaaS], [Books], or [Consulting] identifier.
 * Version: 1.0.1
 * Author: MIFECO
 */

if (!defined('ABSPATH')) exit;

class MIFECO_Mailer {
    private $secret_key = 'Rm2214ri%%%%';
    private $from_email = 'rmills@mifeco.com';
    private $from_name = 'MIFECO';
    
    public function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }
    
    public function register_routes() {
        register_rest_route('mifeco/v1', '/send-email', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_send_email'],
            'permission_callback' => [$this, 'verify_request'],
        ]);
    }
    
    public function verify_request($request) {
        return $request->get_param('secret') === $this->secret_key;
    }
    
    public function handle_send_email($request) {
        $email_data = $request->get_param('email');
        if (!$email_data || !isset($email_data['subject']) || !isset($email_data['body'])) {
            return new WP_REST_Response(['success' => false, 'error' => 'Missing required fields'], 400);
        }
        
        $subject = sanitize_text_field($email_data['subject']);
        $body = wp_kses_post($email_data['body']);
        $to = isset($email_data['to']) ? sanitize_email($email_data['to']) : $this->from_email;
        $pipeline = isset($email_data['pipeline']) ? sanitize_text_field($email_data['pipeline']) : '';
        
        // Ensure subject has pipeline identifier
        $identifiers = ['SaaS', 'Books', 'Consulting'];
        $found_identifier = '';
        foreach ($identifiers as $id) {
            if (stripos($subject, "[$id]") !== false) {
                $found_identifier = $id;
                break;
            }
        }
        if (!$found_identifier && $pipeline && in_array(ucfirst(strtolower($pipeline)), $identifiers)) {
            $found_identifier = ucfirst(strtolower($pipeline));
            $subject = '[' . $found_identifier . '] ' . $subject;
        }
        
        $headers = [
            'From: ' . $this->from_name . ' <' . $this->from_email . '>',
            'Reply-To: ' . $this->from_email,
            'Content-Type: text/html; charset=UTF-8',
            'X-MIFECO-Pipeline: ' . $found_identifier,
        ];
        
        $sent = wp_mail($to, $subject, nl2br($body), $headers);
        return new WP_REST_Response([
            'success' => $sent,
            'to' => $to,
            'subject' => $subject,
            'pipeline' => $found_identifier,
        ], $sent ? 200 : 500);
    }
}

new MIFECO_Mailer();
