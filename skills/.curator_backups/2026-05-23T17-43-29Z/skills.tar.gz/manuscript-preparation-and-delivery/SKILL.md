---
name: manuscript-preparation-and-delivery
description: Workflow for preparing completed manuscripts for review and delivery, including file consolidation, front matter creation, and messaging platform delivery
category: creative
---

# Manuscript Preparation and Delivery

A systematic approach for preparing long-form fiction manuscripts for review and delivery, including file consolidation, front matter creation, formatting consistency, and messaging platform delivery.

## When to Use This Skill

Use this workflow when:
- A manuscript is complete but split across multiple chapter files
- Need to deliver a consolidated, properly formatted version to a reviewer
- Want to maintain consistency with existing books in a series
- Preparing manuscripts for external review or publication
- **Publishing any book — fiction or non-fiction** — from raw manuscript to retailer-ready package
- **Building or rebuilding a unified publishing package for a book series/trilogy** (multiple books in a single zip with their own covers, manuscripts, and shared compliance docs)
- **Updating assets in an existing series package** (e.g., replacing covers for all 3 books and rebuilding the zip)
- **Non-fiction/guide/playbook publishing** — books with subtitle, series branding, and author tagline on the cover (different typography hierarchy than fiction)
- **Splitting a long manuscript into two books** at a page/chapter boundary — see the "Splitting a Manuscript into Two Books" section below

**Reference:** `references/editorial-pass-pov-conversion.md` has a full list of POV conversion artifacts found in Bob's memoir manuscripts, with before/after examples and detection scripts.
**Reference:** `references/page-count-compression-guide.md` has the content-compression techniques for hitting 180-200 page targets without changing CSS. Covers scene-break trimming, proportional sentence trimming, and PDF→HTML rebuild strategies with measured wpp rates for standard 6×9 typography.
**Reference:** `references/chapter-word-count-analyzer.py` — reusable script for per-chapter word count analysis and bulk expansion to target word counts. Use when planning content redistribution across book volumes or expanding short books to hit page targets.
**Reference:** `references/generic-paragraph-detection.md` — comprehensive list of generic/placeholder paragraph patterns found in AI-expanded prose, with replacement strategies for best-selling quality.
**Reference:** `references/transition-hook-templates.md` — reusable first-chapter opening hooks and last-chapter closing hooks for multi-volume series transitions.

**Reference:** `references/fabricated-claim-detection.md` — systematic technique for scanning non-fiction manuscripts and rewriting fabricated first-person claims (specific dollar amounts, named characters, "I built X at MIFECO" stories) as anonymized/anonymous case studies. Includes detection patterns, replacement framing table, and verification steps. Use this editorial pass BEFORE packaging when the user says the manuscript has "made up fictional descriptions" of what they or their company did.

References: references/fabricated-claim-correction.md — systematic approach for detecting and rewriting fabricated first-person claims in non-fiction manuscripts into anonymized case studies. Includes detection patterns, framing options, and the downstream reference chain pitfall: when relabeling a fabricated character, always grep for ALL remaining occurrences of the character name and any family/relational terms near it.

## Prerequisites

- Manuscript chapters should be in individual Markdown files (e.g., `Chapter_01_*.md`)
- Previous books in the series should exist for style reference
- Access to messaging platform (Telegram, Discord, etc.) for delivery

## Step-by-Step Process

### 1. Locate and Verify Manuscript Files

```bash
# Navigate to manuscript directory
cd /home/bob/books/Second_Generation/book-sources/Second_Generation

# List and count chapter files
ls Chapter_*.md | sort -V
```

**Key checks:**
- Verify all expected chapters exist (count should match target)
- Ensure files are in correct order (Chapter_01 through Chapter_64)
## Step-by-Step Process

### 1. Locate and Verify Manuscript Files

```bash
# Navigate to manuscript directory
cd /home/bob/books/Second_Generation/book-sources/Second_Generation

# List and count chapter files
ls Chapter_*.md | sort -V
```

**Key checks:**
- Verify all expected chapters exist (count should match target)
- Ensure files are in correct order (Chapter_01 through Chapter_64)
- Check for any missing or corrupted files

### 2. Consolidate Chapter Files

```bash
# Create combined file from sorted chapters
cat $(ls Chapter_*.md | sort -V) > /tmp/Manuscript_Combined.md
```

**Best practices:**
- Use `sort -V` for proper numerical sorting of chapter numbers
- Add spacing between chapters if needed (double newline)
- Verify line count matches expectations

### 3. Create Enhanced Version with Front Matter

Create a comprehensive front matter section including:
- Cover Page: Title and subtitle, author attribution (if applicable), version number, inspirational quote, series context
- Table of Contents: List all chapters with proper numbering, include bridge sections if applicable, format for easy navigation
- Introduction: Set context for the book's place in the series, establish thematic connections to previous works, preview central conflicts and character arcs, maintain consistent tone with series

### 4. Format Consistency Check

Compare with existing books in the series:

```bash
# Review structure of previous book
head -100 /path/to/First_Generation_Manuscript.md
```

**Elements to match:**
- Chapter header format (`## Chapter X — Title`)
- Mission AI dialogue snippet placement
- Bridge section formatting
- Overall document structure

### 5. Final Assembly

```bash
# Combine front matter with consolidated chapters
cat cover_and_toc.md Manuscript_Combined.md > /tmp/Final_Manuscript.md

# Add completion footer
echo -e "\\n\\n---\\n\\n*Second Generation — Complete*\\n\\n*64 Chapters — Martian Sovereignty Saga*" >> /tmp/Final_Manuscript.md
```

### Non-fiction / Guide Business Book Print HTML

For non-fiction/guide books (different structure from fiction memoirs):

**CSS differences from fiction:**
- Standard 6×9in trim: `@page { size: 6in 9in; margin: 1in; }`
- Body text: 12pt Times New Roman, 1.5 line spacing, justified
- Chapter headers: 20pt, centered, page-break-before
- Subheadings: 14pt, margin-top 20px

**HTML structure:**
```
Cover page → Title page → Copyright page → TOC → Chapters (h2 + h3 + paragraphs)
```

**Markdown-to-HTML conversion pattern:**
```python
for line in content_lines:
    if line.startswith('## Chapter'):
        html.append('<div class="chapter"><h2>CHAPTER TEXT</h2>')
    elif line.startswith('### '):
        html.append(f'<h3>{line[4:]}</h3>')
    elif line.strip().startswith('- '):
        html.append(f'<li>{line.strip()[2:]}</li>')
    elif line.strip():
        html.append(f'<p>{line.strip()}</p>')
```


**When delivering manuscripts as HTML files with professional formatting:**

#### A. Create HTML Structure with CSS Paged Media

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <title>Book Title</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Times+New+Roman:ital,wght@0,400;0,700;1,400&display=swap');
        
        /* Page setup for A4 printing */
        @page {
            size: A4;
            margin: 2.5cm;
            @top-right {
                content: \"Page \" counter(page);
                font-family: 'Times New Roman', Times, serif;
                font-size: 10pt;
            }
            @top-left {
                content: \"Book Title\";
                font-family: 'Times New Roman', Times, serif;
                font-size: 10pt;
            }
        }
        
        body {
            font-family: 'Times New Roman', Times, serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            line-height: 1.6;
            font-size: 12pt;
            color: #000;
        }
        
        /* Chapter formatting */
        .chapter {
            margin: 60px 0 40px 0;
            page-break-before: always;
        }
        
        .chapter-title {
            font-size: 20pt;
            font-weight: bold;
            border-bottom: 2px solid #000;
            padding-bottom: 15pt;
            margin-bottom: 30px;
            page-break-before: always;
        }
        
        /* Title page */
        .title-page {
            text-align: center;
            padding: 60px 0 40px 0;
            border-bottom: 2px solid #000;
            margin-bottom: 50px;
            page-break-after: always;
        }
        
        .title {
            font-size: 42pt;
            font-weight: bold;
            margin-bottom: 30px;
            text-transform: uppercase;
            line-height: 1.2;
        }
        
        .author {
            font-size: 24pt;
            margin-bottom: 40px;
        }
        
        /* TOC formatting */
        .toc {
            margin: 40px 0 60px 0;
            padding: 30px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
            page-break-after: always;
        }
        
        .toc-title {
            font-size: 16pt;
            font-weight: bold;
            margin-bottom: 30px;
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 10pt;
        }
        
        .toc-entry {
            margin: 8px 0;
            text-indent: -20px;
            padding-left: 20px;
            font-size: 11pt;
        }
        
        .toc-page {
            float: right;
            width: 40px;
            text-align: right;
        }
        
        /* Page break utilities */
        .page-break-before {
            page-break-before: always;
        }
        
        .page-break-after {
            page-break-after: always;
        }
    </style>
</head>
<body>
    <!-- Content goes here -->
</body>
</html>
```

#### B. Add Proper Spacing Around Chapter Titles

```python
def add_title_spacing(html_content):
    \"\"\"Add blank lines before and after chapter titles.\"\"\"
    lines = html_content.split('\\n')
    new_lines = []
    i = 0
    
    while i < len(lines):
        line = lines[i]
        
        # Check for chapter heading (### Chapter ...)
        if line.strip().startswith('### '):
            # Add blank lines before heading if needed
            if i > 0 and lines[i-1].strip() != '':
                new_lines.append('')
                new_lines.append('')
            
            new_lines.append(line)
            
            # Add blank lines after heading
            j = i + 1
            while j < len(lines) and lines[j].strip() == '':
                j += 1
            
            if j < len(lines):
                new_lines.append('')
                new_lines.append('')
            
            i += 1
            continue
        
        new_lines.append(line)
        i += 1
    
    return '\\n'.join(new_lines)
```

#### C. Generate Table of Contents with Page Numbers

```python
def generate_toc(chapter_data, css_class=\"toc\"):
    \"\"\"Generate TOC HTML with page numbers.\"\"\"
    toc_html = f'<div class=\"{css_class}\">\\n'
    toc_html += '<h2 class=\"toc-title\">Table of Contents</h2>\\n'
    toc_html += '<ul>\\n'
    
    for i, chapter in enumerate(chapter_data, 1):
        toc_html += f'<li class=\"toc-entry\">'
        toc_html += f'<span>{chapter[\"title\"]}</span>'
        toc_html += f'<span class=\"toc-page\">PAGE {chapter[\"page\"]}</span>'
        toc_html += '</li>\\n'
    
    toc_html += '</ul>\\n</div>\\n'
    return toc_html
```

#### D. Assemble Complete Book

```python
# 1. Create front matter
front_matter = f'''\\n<div class=\"title-page\">
    <h1 class=\"title\">The Future is Unwritten</h1>
    <div class=\"author\">A Memoir by Bob</div>
    <div class=\"publisher small-caps centered\">
        Hermes Publishing
    </div>
    <div class=\"centered\" style=\"margin-top: 40px;\">
        2026
    </div>
</div>

<div class=\"copyright\">
    <p><strong>Copyright © {year} by Bob</strong></p>
    <p>All rights reserved. No part of this publication may be reproduced, distributed, or transmitted in any form or by any means, without the prior written permission of the publisher, except in the case of brief quotations embodied in critical reviews and certain other noncommercial uses permitted by copyright law.</p>
    <p><strong>This book was created using AI-assisted writing techniques.</strong> The author retains final editorial control and fact-checking authority over all content.</p>
    <p><strong>Hermes Publishing</strong><br>
    Distributed by: Hermes Agent<br>
    <a href=\"mailto:bob@hermes.ai\">bob@hermes.ai</a></p>
    <hr>
    <p><strong>Library of Congress Control Number</strong>: 2023901234<br>
    <strong>ISBN</strong>: 978-1-234-56789-0</p>
</div>

<div class=\"dedication\">
    <p><em>For my family,</em></p>
    <p><em>who inspired every word.</em></p>
</div>

{generate_toc(chapter_data)}
'''

# 2. Add chapters with proper formatting
chapters_html = \"\"\"
for chapter in chapter_data:
    chapters_html += f'<div class=\"chapter page-break-before\">\\n'
    chapters_html += f'<h2 class=\"chapter-title\">{chapter[\"title\"]}</h2>\\n'
    chapters_html += f'<div class=\"chapter-content\">\\n{chapter[\"content\"]}\\n</div>\\n'
    chapters_html += f'</div>\\n'

# 3. Add back matter
back_matter = f'''\\n<div class=\"back-cover page-break-before\">
    <h2 class=\"back-title\">The Future is Unwritten</h2>
    <p class=\"back-quote\">\\\"A powerful memoir about technology, humanity, and the spaces between.\\\"</p>
    <p class=\"back-quote\">\\\"Bob's journey from Fermilab to the frontiers of AI will inspire and challenge you.\\\"</p>
</div>

<div class=\"acknowledgments page-break-before\">
    <h2 class=\"acknowledgments-title\">Acknowledgments</h2>
    <p>This book would not have been possible without the support of...</p>
</div>

<div class=\"about-author page-break-before\">
    <h2 class=\"about-author-title\">About the Author</h2>
    <p>Bob is a technologist, writer, and futurist...</p>
</div>\\n'''

# 4. Combine everything
full_html = f'''\\n<!DOCTYPE html>\\n<html>\\n<head>\\n    <meta charset=\"utf-8\">\\n    <title>The Future is Unwritten</title>\\n    <style>\\n        {CSS_STYLES}\\n    </style>\\n</head>\\n<body>\\n    {front_matter}\\n    {chapters_html}\\n    {back_matter}\\n</body>\\n</html>\\n'''

# 5. Write to file
write_file('/tmp/book_complete_enhanced.html', full_html)
```

### 7. Delivery via Messaging Platform

**Identify delivery target:**
```python
# List available messaging targets
send_message(action='list')
```

**Send file:**
```python
# Send as media/document
send_message(
    target='telegram:Robert Mills (dm)',
    message='MEDIA:/tmp/book_complete_enhanced.html'
)
```

**Alternative delivery methods:**
- Email attachment
- Cloud storage link
- Direct file transfer

### Quality Assurance

**Verification steps:**
- **Humanization mandate**: ALL book prose — front matter narrative, transitions, bridge content, part divider pages, about-the-author sections — MUST pass the `humanizer` skill's 29 pattern checks. No AI-isms, no filler, real voice, variable rhythm. Mandatory for every piece of book text.
- **Reader engagement mandate**: All added material — front matter narrative, transitions, bridge content, part divider pages, about-the-author sections — MUST be interesting, exciting, and engaging to readers. No filler text, no generic publishing boilerplate that doesn't serve the reader's experience.
- Confirm file size and line count
- Check that all chapters are present
- Verify front matter formatting
- Test delivery receipt
- **Character name audit**: Confirm ALL character first names come from the top 50 most common US first names (SSA data). Names like Elena, Diego, Rajiv, Mei-Lin, Jean-Luc, Aisha, Ana, Kenji are AI-generated tropes and must be replaced with James, Robert, Michael, David, Elizabeth, Margaret, Susan, Barbara, Christopher, Richard, etc.

**Common pitfalls to avoid:**
- Forgetting to sort chapter files numerically
- Missing chapters due to file naming inconsistencies
- Inconsistent formatting between front matter and chapters
- Delivery to wrong chat target

### Rapid Assembly for Large Manuscripts (40+ Chapters)

When dealing with very large manuscripts (40-64 chapters), a single complex `python` consolidation script may hit terminal timeouts or memory constraints. Use a tiered `cat` approach to build the master file:

1. **Part Consolidation:** Group chapters into batches of 10 using wildcards.
   ```bash
   cat book-sources/Chapter_0[1-9]_*.md book-sources/Chapter_10_*.md > Part_1.md
   cat book-sources/Chapter_1[1-9]_*.md book-sources/Chapter_20_*.md > Part_2.md
   ```
2. **Master Merge:** Join the part files into the final manuscript.
   ```bash
   cat Part_1.md Part_2.md Part_3.md Part_4.md > Final_Manuscript.md
   ```

## Splitting a Manuscript into Two Books

When the user asks to split a long manuscript into two (or more) volumes at a page/chapter boundary (e.g., "split after 100 pages", "make this a two-part series"), follow this workflow.

### When to Use
- User says "split this book into two volumes", "divide after chapter X", "make it a two-parter", "cut at ~N pages"
- A single manuscript is too long for a standard book and needs to become a duology
- The manuscript has a natural narrative break point (escalation point, time jump, perspective shift)

### Step 1: Find the Split Point

Analyze cumulative word counts per chapter to locate the target page boundary (250 words/page approximation):

```python
import re
with open("manuscript.md") as f:
    content = f.read()

# Split by chapter headers
chunks = re.split(r'^## Chapter (\d+)', content, flags=re.MULTILINE)

chapters = {}
current_num = None
for chunk in chunks:
    chunk = chunk.strip()
    if not chunk: continue
    if chunk.isdigit():
        current_num = int(chunk)
    elif current_num is not None:
        words = len(chunk.split())
        chapters[current_num] = words

cumulative = 0
target_pages = 100  # or user-specified number
target_words = target_pages * 250
for num in sorted(chapters):
    cumulative += chapters[num]
    if cumulative >= target_words:
        print(f"Split after Chapter {num}: {cumulative} words ({cumulative/250:.0f} pages)")
        break
```

### Step 2: Split the Manuscript at the Chapter Boundary

Use Python's `re.split()` on `## Chapter N — Title` headers to split the manuscript content into two parts:

```python
chunks = re.split(r'^(## Chapter \d+ [—\-–].+)$', content, flags=re.MULTILINE)

# Reconstruct chapter list
chapters = []
current_header = None
for chunk in chunks:
    if chunk.startswith("## Chapter ") and re.match(r'^## Chapter \d+ [—\-–]', chunk):
        if current_header:
            chapters.append({"header": current_header, "body": current_body})
        current_header = chunk
        current_body = ""
    elif current_header:
        current_body += chunk
if current_header:
    chapters.append({"header": current_header, "body": current_body})

split_idx = SPLIT_CHAPTER_NUM - 1  # 0-indexed
part1 = chapters[:split_idx]
part2 = chapters[split_idx:]

# Write Part 1 with new header
with open("part1/manuscript.md", "w") as f:
    f.write(f"# {title} - Part 1\n\n---\n\n")
    for ch in part1:
        f.write(ch["header"] + "\n" + ch["body"])

# Write Part 2 with renumbered chapters
with open("part2/manuscript.md", "w") as f:
    f.write(f"# {title} - Part 2\n\n---\n\n")
    new_num = 1
    for ch in part2:
        # Renumber: Chapter 19 → Chapter 1, etc.
        new_header = re.sub(r'Chapter \d+', f'Chapter {new_num}', ch["header"], count=1)
        f.write(new_header + "\n" + ch["body"])
        new_num += 1
```

### Step 3: Rewrite the Boundary Chapters

The split point needs two targeted rewrites:
- **Last chapter of Part 1** — rewrite as a series-ending chapter. Themes: resolution of the book's central conflict, characters reflecting on how far they've come, a viewport/observation scene, and a bridge paragraph that sets up what's coming in Part 2.
- **First chapter of Part 2** — rewrite the opening to include a book-level Mission AI ping, a summary transition (the "bridge" from Part 1's cliffhanger or resolution), and the original chapter content. Renumber to Chapter 1.

Watch for pattern: the original chapter likely opens with a `*Mission AI: ...*` quote and a character quote. Replace these with new book-opening variants, but keep the rest of the chapter body intact.

### Step 4: Verify and Clean

- Check for duplicate Mission AI or character quote pairs at the Part 2 opening (the old opening lines get duplicated when you insert new ones)
- Verify chapter renumbering is complete — every `Chapter N` in headers, but NOT in body text or dialogue
- Check that the TOC/list of chapter titles is removed from the front matter of Part 2 (it belongs in the original manuscript's front matter)

### Step 5: Generate Covers and Publishing Package

Follow the standard cover generation workflow (see `openrouter-image-generation-workflow` skill):
1. Generate raw art via Gemini Flash Image or Flux.2 with "leave top 40% empty" constraint
2. Resize from square to 2:3 portrait (1024×1536)
3. Apply typography: stacked title, subtitle ("PART 1" / "PART 2"), author name on dark rounded box

Then build the full publishing package (HTML with embedded cover + EPUB + PDF) using the publishing pipeline described in this skill.

### Pitfalls
- `## Chapter N` (bare number, no dash/title) appears before the full header in some manuscripts — match only `## Chapter N — Title` (with em-dash) to avoid double-splitting
- Chapter renumbering in Part 2 header bodies — only renumber `## Chapter N —` header lines, not dialogue references like "back in Chapter 19..."
- Duplicate Mission AI lines when rewriting Chapter 1 of Part 2 — the old opening lines survive unless explicitly removed
- Cover filename mismatch — the cover generation script and the publishing script must use the same filename prefix (e.g., both `Book_Name_Part_1_Cover.png`)
- **Subagent timeout on large rewrites**: Delegating a 23K-word book rewrite to `delegate_task` will timeout at 600s. The subagent makes 10-15 tool calls then times out, leaving the file partially written or one book rewritten but a second untouched. Use `execute_code` with Python scripts for all book rewriting. Break into batches of 4-5 chapters per call. For duplicate books needing full rewrites, use the `bulk_expand` technique (inserting `<p>` blocks at `</p>` boundaries) rather than subagents.

### Example
This workflow was used to split "Second Generation" (64 chapters, 92,476 words, ~370 pages) into "Second Generation - Part 1" (18 chapters, 99 pages) and "Second Generation - Part 2" (46 chapters, 269 pages) at Chapter 18 (~101 pages).

---

### Fallback Image Generation (Pollinations)

If OpenRouter or Gemini image endpoints are blocked, unavailable, or hit rate limits during a book production run, use the Pollinations.ai no-key web endpoint for rapid cover generation:

```python
import requests, urllib.parse
from PIL import Image
from io import BytesIO

prompt = "cinematic book cover..."
url = f"https://image.pollinations.ai/prompt/{urllib.parse.quote(prompt)}?width=1024&height=1536&nologo=true"
r = requests.get(url, timeout=120)
img = Image.open(BytesIO(r.content)).save("cover.png")
```

### High-Volume Parallel Drafting

For 40+ chapter books, orchestrate three subagents in parallel batches of 4 chapters each. This maximizes throughput while avoiding the token/timeout limits associated with writing 5+ chapters in a single agent turn.

**Transition Generation:** Created personal, integrated transitions (10-20 sentences each) that incorporate historical context and physiological effects, enhancing narrative flow between chapters.

**Image Placeholder Creation:** Generated placeholder images for cover and chapter sketches to support visual storytelling elements.

**Professional Formatting:** Applied Times New Roman, proper margins, CSS styling, and print-ready layout for publication-quality output.

**Systematic Workflow:** Developed a comprehensive approach from manuscript assembly through delivery, including error handling and quality assurance.

**HTML Structure Diagnosis and Correction:** Implemented a systematic approach for identifying and fixing HTML structure issues, particularly image placement problems (e.g., images incorrectly placed in Table of Contents vs. after chapter headings).

**PDF Conversion with WeasyPrint:** Added capability to convert HTML manuscripts to PDF with proper formatting, ensuring cross-platform compatibility and professional output.

**Quality Assurance for Professional Formatting:** Established comprehensive verification steps to ensure proper spacing, image placement, and overall document structure before delivery.
- Email: Attach file directly
- Discord: Use file upload with proper description

### Example Use Cases

1. **Series continuation:** Prepare Book 2 in a trilogy following the same format as Book 1
2. **Manuscript revision:** Update a completed book with new front matter for reprint
3. **Multi-format delivery:** Create different versions (Markdown, PDF, EPUB) for various reviewers
4. **Beta reader distribution:** Prepare clean, formatted copies for feedback

### Success Metrics

- All 64 chapters present and in correct order
- Front matter matches series style guide
- File delivered successfully to intended recipient
- Recipient can open and review without formatting issues

### Notes and Lessons Learned

- Always verify chapter count before consolidation
- Use version control for manuscript files when possible
- Keep templates for front matter to ensure consistency
- Test delivery on target platform beforehand if possible

#

## Book Cover Typography Standards

When generating covers, the typography layout depends on the **book genre**:

### Fiction / Sci-Fi / Memoir (Two-line titles)
- **Title**: White bold text, stacked vertically (one word per line)
- **Title font size**: 30pt (approx 40px for 1024px width images)
- **Author**: "Bob Mills" in white, centered at bottom
- **Author font size**: 16pt (approx 21px)
- **Background**: Semi-transparent charcoal boxes (RGBA 0,0,0,140) behind both title and author text
- **Title box**: Top third of cover, roughly [250, 100, 774, 100+(words*70)]
- **Author box**: Bottom portion, roughly [350, h-200, 674, h-130]

### Non-fiction / Guide / Business Books (Multi-line titles with subtitle + branding)
These books have a different typography hierarchy with more elements:
- **Title**: Bold white text, stacked vertically — can be 2-4+ words ("AI FOR SMALL BUSINESS", not just "FIRST GENERATION")
- **Title font size**: 58-76pt (larger for visual impact on business covers), positioned 30-50px from top
- **Subtitle**: Smaller italic/lighter white text (~22pt), positioned ~30px below the last title line
- **Series/Branding tag**: Small text (~16pt) identifying the series or imprint ("MIFECO PRACTICAL GUIDE"), below subtitle
- **Author**: White text (~28pt), centered ~100-130px from bottom edge
- **Background**: Subtle dark gradient overlay at top (extending ~18% of cover height, alpha 0-50) and bottom (~15%, alpha 0-40) for text readability over any artwork
- **Shadow**: Multi-layer shadow approach (2px offset black at alpha 200, then 1px at alpha 100) for legibility over complex backgrounds

### Font Path (Linux)
```python
font_path = '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'
# Fallbacks: /usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf
# Fallbacks: /usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf
```

## Building Compliance Documentation

When creating a publishing package, include compliance docs alongside the manuscript and cover. The two essential documents are:

### KDP AI Disclosure

Create this file whenever the book used AI assistance. Follow Amazon KDP guidelines:
- Distinguish **AI-Assisted** (human steering/editing with AI drafting support) from **AI-Generated** (fully automated with minimal human review)
- Disclose separately for **Text**, **Cover Images**, and **Translations**
- State the model/provider used (e.g., "Google Gemini 2.5 Flash Image on OpenRouter")
- Describe the human review process (e.g., "Every chapter was reviewed, refined, and approved by the human author")

Template structure:
```markdown
# KDP AI DISCLOSURE RECORD: [BOOK TITLE]

## Summary
This book utilized AI-assistance in its creation. Following Amazon KDP's transparency guidelines...

## AI Involvement

### Text Content: AI-Assisted
Human-defined [structure/outline/topics] by [Author]. AI-assisted [drafting/refinement] using [tool details].
Every chapter was reviewed, refined, and approved by the human author.

### Cover Image: AI-Generated
Generated via [model/provider], with typography overlay by [Author].

## KDP Classification
- **Text:** AI-Assisted
- **Images:** AI-Generated
- **Translations:** N/A
```

### Marketing Copy

Include both short (200 char) and long (Amazon-style) descriptions, plus categories, keywords, and target audience.

Template structure:
```markdown
# [BOOK TITLE]: MARKETING COPY

## Book Title
**[Title]: [Subtitle]**

## Author
[Name]

## Description (Short - 200 characters)
[One compelling sentence...]

## Description (Long - Amazon style)
[Full blurb with hook, value prop, and call to action...]
**Inside you'll discover:**
- [Bullet 1]
- [Bullet 2]
...

## Categories
- [Category 1]
- [Category 2]

## Keywords
[comma-separated keywords]

## Target Audience
[description of ideal reader]
```

### README / Package Manifest

Create a README.md at the package root that documents:
- Book title, author, series
- Package contents (what's in each folder)
- Book details (format, trim size, estimated pages, language)
- Publishing notes (ISBN assignment, distribution, retailer-specific steps)

## Package Assembly Step-by-Step

After the manuscript is finalized and the cover is generated, assemble the complete retailer-ready package:

### Step 1: Create Cover_Clean.png

Generate a clean version of the cover art (no typography) from the canvas/extended version:

```python
from PIL import Image, ImageDraw

# Open the extended canvas (with gradient overlays already applied, if any)
img = Image.open("cover_canvas.png").convert("RGBA")
w, h = img.size

# Re-apply gradient overlays (if the canvas doesn't already have them)
overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
draw_o = ImageDraw.Draw(overlay)

# Top gradient for title zone
grad_height = int(h * 0.38)
for y in range(grad_height):
    alpha = int(140 * (1 - y / grad_height))
    if alpha > 0:
        draw_o.rectangle([0, y, w, y+1], fill=(0, 0, 0, min(alpha, 100)))

# Bottom gradient for author zone
bot_grad = int(h * 0.12)
for y in range(bot_grad):
    alpha = int(130 * (y / bot_grad))
    if alpha > 0:
        draw_o.rectangle([0, h - bot_grad + y, w, h - bot_grad + y + 1], fill=(0, 0, 0, min(alpha, 90)))

img = Image.alpha_composite(img, overlay).convert("RGB")
img.save("BookName_Cover_Clean.png")
```

### Step 2: Create Marketing_Copy.md

Write short + long descriptions, categories, keywords, target audience, and series info. Use the following structure for the long description:

```
**A compelling hook sentence**

[1-2 paragraphs establishing stakes, setting, and central conflict]

**Inside you'll discover:**
- [Authentic detail about the book]
- [Character-focused benefit]
- [Genre promise]
- [Emotional/thematic takeaway]
```

Categories: 3-5 Amazon BISAC categories. Keywords: 12-15 comma-separated.
Target audience: reference similar authors/books (e.g., "Readers of [Author A], [Author B], and fans of [Series Name]").

### Step 3: Create KDP_AI_Disclosure.md

Document the specific models/tools used and the human review process:

```markdown
# KDP AI DISCLOSURE RECORD: [BOOK TITLE]

## Summary
This book utilized AI-assistance in its creation. Following Amazon KDP's transparency guidelines...

## AI Involvement

### Text Content: AI-Assisted
Human-defined [structure/outline/topics] by [Author]. AI-assisted [drafting/refinement] using [specific models].
Every chapter was reviewed, refined, and approved by the human author.

### Cover Image: AI-Generated
Generated via [model/provider], with typography overlay by [Author].

## KDP Classification
- **Text:** AI-Assisted
- **Images:** AI-Generated
- **Translations:** N/A
```

### Step 4: Create README.md (Package Manifest)

Document book details (title, author, genre, format, page count, chapters, word count), 
package contents with file descriptions, publishing notes (ISBN, distribution recommendations),
version history, and compliance notes.

### Step 5: Assemble Final Package Directory

```python
import shutil, os
from pathlib import Path

pkg_root = Path("BookName_FINAL_PACKAGE")
for d in [pkg_root / "Cover", pkg_root / "Source", pkg_root / "Marketing_and_Compliance"]:
    d.mkdir(parents=True, exist_ok=True)

# Copy main files
shutil.copy2("BookName_With_Cover.pdf", pkg_root / "BookName_With_Cover.pdf")
shutil.copy2("BookName.html", pkg_root / "BookName.html")
shutil.copy2("BookName_Cover.png", pkg_root / "Cover" / "BookName_Cover.png")
shutil.copy2("BookName_Cover_Clean.png", pkg_root / "Cover" / "BookName_Cover_Clean.png")
shutil.copy2("BookName_Manuscript.md", pkg_root / "Source" / "BookName_Manuscript.md")
shutil.copy2("Marketing_Copy.md", pkg_root / "Marketing_and_Compliance" / "Marketing_Copy.md")
shutil.copy2("KDP_AI_Disclosure.md", pkg_root / "Marketing_and_Compliance" / "KDP_AI_Disclosure.md")
shutil.copy2("README.md", pkg_root / "README.md")
```

### Step 6: Create ZIP Package

```bash
cd /path/to/parent && zip -r BookName_FINAL_PACKAGE.zip BookName_FINAL_PACKAGE/
```

Or in Python:
```python
import zipfile
with zipfile.ZipFile("BookName_FINAL_PACKAGE.zip", 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(pkg_root):
        for f in files:
            filepath = os.path.join(root, f)
            arcname = os.path.relpath(filepath, pkg_root.parent)
            zf.write(filepath, arcname)
```

### Single Book Package Structure (Final)

```
BookName_FINAL_PACKAGE/
├── BookName_With_Cover.pdf         # Print-ready PDF with cover as first page
├── BookName.html                   # Lightweight HTML (no embedded cover image)
├── README.md                       # Package manifest
├── Cover/
│   ├── BookName_Cover.png          # Cover with typography
│   └── BookName_Cover_Clean.png    # Clean art (no text, for custom setups)
├── Source/
│   └── BookName_Manuscript.md      # Full manuscript in Markdown
└── Marketing_and_Compliance/
    ├── Marketing_Copy.md           # Descriptions, categories, keywords, target audience
    └── KDP_AI_Disclosure.md        # AI-use record for retailer compliance
```

When auditing memoirs or manuscripts that used AI-assisted writing, check for and remove these templated transition artifacts:

### Common AI Transition Patterns to Remove
These patterns indicate placeholder AI-generated transitions, not real content:
- `"Leaving behind 'X' and turning toward 'Y', I inhabited a mental landscape..."`
- `"As the memory of 'X' gave way to the story of 'Y'..."`
- `"Moving from 'X' to 'Y', I inhabited what I've come to think of as..."`
- `"The shift from contemplating 'X' to engaging with 'Y' carried me through..."`
- `"Between the recollection of 'X' and the unfolding of 'Y', my mind rested in..."`
- `"As I moved from reflecting on 'X' to confronting 'Y', I found myself in..."`
- `"In that space, I began to see connections I had missed before..."`
- `"What I discovered there changed how I understood both experiences..."`
- `"creative tension between memory and possibility"`
- `"my mind rested in a space of integration"`
- `"memories blend with anticipation"`
- `"psychological threshold"`

### Third-Person POV Conversion Artifacts (Memoir Specific)
When a memoir was written in first-person and later converted to third-person ("I" → "Bob"), these residual artifacts commonly survive conversion and must be caught in editorial review:

**"Bob would [verb]" where past tense needed:**
This is the most common artifact. The converter replaces "I would" literally instead of simplifying to past tense.
- `"Bob would ordered"` → `"Bob had ordered"` (or `"Bob ordered"`)
- `"Bob would learned"` → `"Bob had learned"`
- `"Bob would said"` → `"Bob had said"` (or `"Bob said"`)
- `"Bob would gotten"` → `"Bob had gotten"`
- `"Bob would had"` → `"Bob had"`

Search: `Bob would (ordered|learned|said|gotten|had|asked|told|made|built|known|gone)`

**Verb agreement errors from "I"-to-"Bob" substitution:**
The converter replaces "I" with "Bob" without adjusting verb conjugation.
- `"Bob carry"` → `"Bob carries"` (also: Bob know → knows, Bob have → has, Bob remember → remembers, Bob wish → wishes, Bob discover → discovers)
- `"Bob still carry"` → `"Bob still carries"`

**Auxiliary verb + past tense errors:**
- `"Did Bob remembered"` → `"Did Bob remember"` (main verb after "did" should be base form)
- `"Bob only remember"` → `"Bob only remembers"` (subject-verb agreement)

**Double-ed endings:**
- `"remembereded"` → `"remembered"`
Likely from regex replacement that added "ed" to an already-past-tense verb.

**First-person pronoun residue in third-person narrative:**
- `"inches from mine"` → `"inches from his"`
- `"curved away from mine"` → `"curved away from his"`
- `"Everything after is mine"` → `"Everything after is his"`
Look for bare `"mine"` at end of possessive phrases.

**"Transition: [Title]" sections that appear twice:**
When content from two source documents is merged, section header + paragraph pairs sometimes duplicate. Search for exact duplicates of any "Transition:" header line.

**Detection script:**
```python
import re
pov_patterns = {
    "Bob_would_verb": re.compile(r"Bob would (ordered|learned|said|gotten|had|asked|told|made|built|known|gone)"),
    "Bob_verb_agreement": re.compile(r"Bob (carry|know|have|remember|wish|discover) s?\\b"),
    "mine_residue": re.compile(r"(from|of|to) mine\\b"),
    "remembereded": re.compile(r"remembereded"),
    "Did_Bob_remembered": re.compile(r"Did Bob remembered"),
}
for label, pattern in pov_patterns.items():
    matches = [(i+1, line.strip()) for i, line in enumerate(lines) if pattern.search(line)]
    if matches:
        print(f"POV artifact '{label}': {len(matches)} occurrences")
```

### Cleaning Workflow
1. Search all lines for the patterns above
2. Remove matching lines and adjacent empty lines
3. Verify zero remaining matches
4. Renumber chapters sequentially
5. Audit Part headers for duplicates or sequence errors
6. Regenerate final HTML/CSS with correct structure

### Code for Pattern Detection
```python
import re
ai_indicators = [
    "gave way to the story of",
    "I inhabited a mental landscape",
    "creative tension between memory",
    "I inhabited what I've come to think of",
    "my mind rested in a space of integration",
    "memories blend with anticipation",
    "psychological threshold",
]
for i, line in enumerate(lines):
    for ind in ai_indicators:
        if ind in line:
            ai_lines.append((i, line.strip()))
            break
```

## Pollinations Cover Generation: Known Issues and Fixes

### Common Failures
1. **Timeouts (120s+)** — The Pollinations API can be slow. Use background processes with `notify_on_complete=True` for batch generation.
2. **Corrupted small files (500-700 bytes)** — The API sometimes returns error HTML instead of image data. Always verify `len(content) > 50000` before treating as valid.
3. **`UnidentifiedImageError`** — PIL fails when given a non-image response. Wrap `Image.open(BytesIO(r.content))` in try/except.
4. **One at a time** — Generate covers individually rather than in batch to avoid cascading timeouts.

### Reliable Pattern
```python
import requests, urllib.parse
from PIL import Image
from io import BytesIO

def gen_cover(path, prompt, seed):
    url = f'https://image.pollinations.ai/prompt/{urllib.parse.quote(prompt)}?width=1024&height=1536&nologo=true&private=true&enhance=true&seed={seed}'
    r = requests.get(url, timeout=120)
    if r.status_code == 200 and len(r.content) > 50000:
        img = Image.open(BytesIO(r.content))
        img.save(path)
        return True
    return False
```

### Then Apply Typography as Separate Step
Never bake text into the image generation prompt — it always produces garbled results. Always:
1. Generate clean background first (no text in prompt)
2. Verify the image is valid (size > 50KB, opens in PIL)
3. Apply typography locally with PIL using transparent overlay boxes

## KDP Package Structure

Final delivery package should follow this structure:

### Single Book Package

```
Book_Name_FINAL_PACKAGE/
├── Manuscript/
│   ├── Book_Name_Clean.md          # Cleaned source manuscript
│   └── Book_Name_Final_Print.html  # Print-ready HTML with embedded CSS and cover
├── Cover/
│   ├── Book_Name_Cover.png          # Cover with typography
│   └── Book_Name_Cover_Clean.png    # Clean art (no text)
└── Marketing_and_Compliance/
    ├── Marketing_Copy.md            # Back-cover blurbs (long + short + HTML)
    └── KDP_AI_Disclosure.md         # AI-use record for retailer compliance
```

### Updating Assets in an Existing Package

Use this workflow when the user requests a change to a single asset (e.g., new cover art) in an already-finalized publishing package — without rebuilding the entire manuscript from scratch.

**Trigger conditions:**
- User says "update the cover" or "rebuild the .zip with the new cover"
- A generated asset (cover image, manuscript HTML) has been replaced and needs integration
- The package directory already exists with the correct structure

**Step-by-step:**

1. **Locate the package:**
   ```bash
   ls /path/to/Book_Name_FINAL_PACKAGE/
   ```
   Confirm the `Cover/` subdirectory exists with the old files.

2. **Copy the new asset into the package:**
   ```python
   import shutil, os
   shutil.copy2(new_cover_path, os.path.join(package_dir, "Cover", "Book_Name_Cover.png"))
   shutil.copy2(new_cover_path, os.path.join(package_dir, "Cover", "Book_Name_Cover_Clean.png"))
   ```
   ⚠️ **Always update both files** — `Cover.png` (with typography) and `Cover_Clean.png` (clean art). Even if the new image has text built-in, copy it to both slots so the user has a consistent file set.

3. **Remove the old zip:**
   ```bash
   rm -f /path/to/Book_Name_FINAL_PACKAGE.zip
   ```

4. **Rebuild the zip:**
   ```bash
   cd /path/to && zip -r Book_Name_FINAL_PACKAGE.zip Book_Name_FINAL_PACKAGE/
   ```

5. **Verify:**
   ```bash
   ls -lh /path/to/Book_Name_FINAL_PACKAGE.zip
   unzip -l Book_Name_FINAL_PACKAGE.zip | grep Cover
   ```
   Confirm the new zip is present, check file size, and verify the cover files are listed with their updated sizes.

**Common pitfalls:**\n- Forgetting to update **both** cover slot files (`Cover.png` and `Cover_Clean.png`)\n- Zipping from an incorrect working directory (zip stores relative paths from cwd)\n- Not removing the old zip first (delivery confusion if both exist)\n- Copying an incomplete/truncated image (always verify `os.path.getsize()` > 50KB)\n\n### Trilogy/Series Package Structure\n\nWhen packaging a multi-book series (e.g., a 3-book trilogy), use a different layout that groups books while keeping shared compliance docs in one place:\n\n```\nSeries_Name_FINAL_PACKAGE/\n├── First_Generation/\n│   ├── First_Generation_Cover.png          # Cover with typography\n│   └── First_Generation_Manuscript.md      # Source manuscript\n├── Second_Generation/\n│   ├── Second_Generation_Cover.png\n│   └── Second_Generation_Manuscript.md\n├── Third_Generation/\n│   ├── Third_Generation_Cover.png\n│   └── Third_Generation_Manuscript.md\n└── Marketing_and_Compliance/\n    ├── Marketing_Copy.md                   # Series-wide blurbs\n    └── KDP_AI_Disclosure.md                # Series-wide AI-use record\n```\n\n**Rebuilding the series package:**\n1. Clear the old package directory: `rm -rf Series_Name_FINAL_PACKAGE/`\n2. Recreate the directory structure with subdirectories per book\n3. Copy each book's cover and manuscript into its subdirectory\n4. Copy shared compliance/marketing docs into `Marketing_and_Compliance/`\n5. Remove old zip, rebuild: `zip -r Series_Name_Release_Package.zip Series_Name_FINAL_PACKAGE/`\n\n**Trigger:** Use this structure when the user says \"rebuild the publishing packages\" for a trilogy/series, or when regenerating covers for all books in a series. The skill `openrouter-image-generation-workflow` handles the cover generation side; this skill handles the packaging side.\n\n## Additional Enhancements

**Transition Generation:** Created personal, integrated transitions (10-20 sentences each) that incorporate historical context and physiological effects, enhancing narrative flow between chapters.

**Image Placeholder Creation:** Generated placeholder images for cover and chapter sketches to support visual storytelling elements.

**Professional Formatting:** Applied Times New Roman, proper margins, CSS styling, and print-ready layout for publication-quality output.

**Systematic Workflow:** Developed a comprehensive approach from manuscript assembly through delivery, including error handling and quality assurance.

**Alternative delivery methods:**
- Email attachment
- Cloud storage link
- Direct file transfer

### Quality Assurance

**Verification steps:**
- **Humanization mandate**: ALL book prose — front matter narrative, transitions, bridge content, part divider pages, about-the-author sections — MUST pass the `humanizer` skill's 29 pattern checks. No AI-isms, no filler, real voice, variable rhythm. Mandatory for every piece of book text.
- **Reader engagement mandate**: All added material — front matter narrative, transitions, bridge content, part divider pages, about-the-author sections — MUST be interesting, exciting, and engaging to readers. No filler text, no generic publishing boilerplate that doesn't serve the reader's experience.
- Confirm file size and line count
- Check that all chapters are present
- Verify front matter formatting
- Test delivery receipt
- **Character name audit**: Confirm ALL character first names come from the top 50 most common US first names (SSA data). Names like Elena, Diego, Rajiv, Mei-Lin, Jean-Luc, Aisha, Ana, Kenji are AI-generated tropes and must be replaced with James, Robert, Michael, David, Elizabeth, Margaret, Susan, Barbara, Christopher, Richard, etc.

**Common pitfalls to avoid:**
- Forgetting to sort chapter files numerically
- Missing chapters due to file naming inconsistencies
- Inconsistent formatting between front matter and chapters
- Delivery to wrong chat target

### Rapid Assembly for Large Manuscripts (40+ Chapters)

When dealing with very large manuscripts (40-64 chapters), a single complex `python` consolidation script may hit terminal timeouts or memory constraints. Use a tiered `cat` approach to build the master file:

1. **Part Consolidation:** Group chapters into batches of 10 using wildcards.
   ```bash
   cat book-sources/Chapter_0[1-9]_*.md book-sources/Chapter_10_*.md > Part_1.md
   cat book-sources/Chapter_1[1-9]_*.md book-sources/Chapter_20_*.md > Part_2.md
   ```
2. **Master Merge:** Join the part files into the final manuscript.
   ```bash
   cat Part_1.md Part_2.md Part_3.md Part_4.md > Final_Manuscript.md
   ```

## Splitting a Manuscript into Two Books

When the user asks to split a long manuscript into two (or more) volumes at a page/chapter boundary (e.g., "split after 100 pages", "make this a two-part series"), follow this workflow.

### When to Use
- User says "split this book into two volumes", "divide after chapter X", "make it a two-parter", "cut at ~N pages"
- A single manuscript is too long for a standard book and needs to become a duology
- The manuscript has a natural narrative break point (escalation point, time jump, perspective shift)

### Step 1: Find the Split Point

Analyze cumulative word counts per chapter to locate the target page boundary (250 words/page approximation):

```python
import re
with open("manuscript.md") as f:
    content = f.read()

# Split by chapter headers
chunks = re.split(r'^## Chapter (\d+)', content, flags=re.MULTILINE)

chapters = {}
current_num = None
for chunk in chunks:
    chunk = chunk.strip()
    if not chunk: continue
    if chunk.isdigit():
        current_num = int(chunk)
    elif current_num is not None:
        words = len(chunk.split())
        chapters[current_num] = words

cumulative = 0
target_pages = 100  # or user-specified number
target_words = target_pages * 250
for num in sorted(chapters):
    cumulative += chapters[num]
    if cumulative >= target_words:
        print(f"Split after Chapter {num}: {cumulative} words ({cumulative/250:.0f} pages)")
        break
```

### Step 2: Split the Manuscript at the Chapter Boundary

Use Python's `re.split()` on `## Chapter N — Title` headers to split the manuscript content into two parts:

```python
chunks = re.split(r'^(## Chapter \d+ [—\-–].+)$', content, flags=re.MULTILINE)

# Reconstruct chapter list
chapters = []
current_header = None
for chunk in chunks:
    if chunk.startswith("## Chapter ") and re.match(r'^## Chapter \d+ [—\-–]', chunk):
        if current_header:
            chapters.append({"header": current_header, "body": current_body})
        current_header = chunk
        current_body = ""
    elif current_header:
        current_body += chunk
if current_header:
    chapters.append({"header": current_header, "body": current_body})

split_idx = SPLIT_CHAPTER_NUM - 1  # 0-indexed
part1 = chapters[:split_idx]
part2 = chapters[split_idx:]

# Write Part 1 with new header
with open("part1/manuscript.md", "w") as f:
    f.write(f"# {title} - Part 1\n\n---\n\n")
    for ch in part1:
        f.write(ch["header"] + "\n" + ch["body"])

# Write Part 2 with renumbered chapters
with open("part2/manuscript.md", "w") as f:
    f.write(f"# {title} - Part 2\n\n---\n\n")
    new_num = 1
    for ch in part2:
        # Renumber: Chapter 19 → Chapter 1, etc.
        new_header = re.sub(r'Chapter \d+', f'Chapter {new_num}', ch["header"], count=1)
        f.write(new_header + "\n" + ch["body"])
        new_num += 1
```

### Step 3: Rewrite the Boundary Chapters

The split point needs two targeted rewrites:
- **Last chapter of Part 1** — rewrite as a series-ending chapter. Themes: resolution of the book's central conflict, characters reflecting on how far they've come, a viewport/observation scene, and a bridge paragraph that sets up what's coming in Part 2.
- **First chapter of Part 2** — rewrite the opening to include a book-level Mission AI ping, a summary transition (the "bridge" from Part 1's cliffhanger or resolution), and the original chapter content. Renumber to Chapter 1.

Watch for pattern: the original chapter likely opens with a `*Mission AI: ...*` quote and a character quote. Replace these with new book-opening variants, but keep the rest of the chapter body intact.

### Step 4: Verify and Clean

- Check for duplicate Mission AI or character quote pairs at the Part 2 opening (the old opening lines get duplicated when you insert new ones)
- Verify chapter renumbering is complete — every `Chapter N` in headers, but NOT in body text or dialogue
- Check that the TOC/list of chapter titles is removed from the front matter of Part 2 (it belongs in the original manuscript's front matter)

### Step 5: Generate Covers and Publishing Package

Follow the standard cover generation workflow (see `openrouter-image-generation-workflow` skill):
1. Generate raw art via Gemini Flash Image or Flux.2 with "leave top 40% empty" constraint
2. Resize from square to 2:3 portrait (1024×1536)
3. Apply typography: stacked title, subtitle ("PART 1" / "PART 2"), author name on dark rounded box

Then build the full publishing package (HTML with embedded cover + EPUB + PDF) using the publishing pipeline described in this skill.

### Pitfalls
- `## Chapter N` (bare number, no dash/title) appears before the full header in some manuscripts — match only `## Chapter N — Title` (with em-dash) to avoid double-splitting
- Chapter renumbering in Part 2 header bodies — only renumber `## Chapter N —` header lines, not dialogue references like "back in Chapter 19..."
- Duplicate Mission AI lines when rewriting Chapter 1 of Part 2 — the old opening lines survive unless explicitly removed
- Cover filename mismatch — the cover generation script and the publishing script must use the same filename prefix (e.g., both `Book_Name_Part_1_Cover.png`)
- **Subagent timeout on large rewrites**: Delegating a 23K-word book rewrite to `delegate_task` will timeout at 600s. The subagent makes 10-15 tool calls then times out, leaving the file partially written or one book rewritten but a second untouched. Use `execute_code` with Python scripts for all book rewriting. Break into batches of 4-5 chapters per call. For duplicate books needing full rewrites, use the `bulk_expand` technique (inserting `<p>` blocks at `</p>` boundaries) rather than subagents.

### Example
This workflow was used to split "Second Generation" (64 chapters, 92,476 words, ~370 pages) into "Second Generation - Part 1" (18 chapters, 99 pages) and "Second Generation - Part 2" (46 chapters, 269 pages) at Chapter 18 (~101 pages).

---

### Fallback Image Generation (Pollinations)

If OpenRouter or Gemini image endpoints are blocked, unavailable, or hit rate limits during a book production run, use the Pollinations.ai no-key web endpoint for rapid cover generation:

```python
import requests, urllib.parse
from PIL import Image
from io import BytesIO

prompt = "cinematic book cover..."
url = f"https://image.pollinations.ai/prompt/{urllib.parse.quote(prompt)}?width=1024&height=1536&nologo=true"
r = requests.get(url, timeout=120)
img = Image.open(BytesIO(r.content)).save("cover.png")
```

### High-Volume Parallel Drafting

For 40+ chapter books, orchestrate three subagents in parallel batches of 4 chapters each. This maximizes throughput while avoiding the token/timeout limits associated with writing 5+ chapters in a single agent turn.

**Transition Generation:** Created personal, integrated transitions (10-20 sentences each) that incorporate historical context and physiological effects, enhancing narrative flow between chapters.

**Image Placeholder Creation:** Generated placeholder images for cover and chapter sketches to support visual storytelling elements.

**Professional Formatting:** Applied Times New Roman, proper margins, CSS styling, and print-ready layout for publication-quality output.

**Systematic Workflow:** Developed a comprehensive approach from manuscript assembly through delivery, including error handling and quality assurance.
    message='MEDIA:/tmp/book_complete_enhanced.html'
)
```

**Alternative delivery methods:**
- Email attachment
- Cloud storage link
- Direct file transfer

## Quality Assurance

**Verification steps:**
- Confirm file size and line count
- Check that all chapters are present
- Verify front matter formatting
- Test delivery receipt

## Editorial Quality Pass: Replacing Generic Prose with Best-Selling Quality

After bulk-expanding chapters to hit word-count targets, a dedicated quality pass
must replace all generic/placeholder paragraphs with dramatic, character-driven content.

### When to Use
- After any bulk-expansion step that added scene-break paragraphs to hit word-count targets
- When the user says "make every chapter interesting, engaging, exciting/dramatic"
- Before delivering a final PDF/EPUB for reader review
- When the prose reads like "the work continued" or "in the silence" filler

### Step 1: Find Generic Paragraphs

Search the HTML for these tell-tale openings:

| Category | Phrases to find |
|----------|----------------|
| Narration | "The work continued through the long hours..." |
| Narration | "In the silence of the habitat..." |
| Narration | "The data painted a complex picture..." |
| Narration | "The implications were staggering..." |
| Narration | "The team gathered around the monitor..." |
| Dialogue | `"We're making progress," someone reported...` |
| Dialogue | `"This doesn't make sense," someone muttered...` |
| Scene | "What are you thinking about?" someone asked... |

See `references/generic-paragraph-detection.md` for the full list plus replacement strategies.

### Step 2: Replace with Character-Driven Content

Each replacement must:
1. **Name specific characters**, not "someone" or "the team"
2. **Show emotion through action** — trembling hands, the valve grip, the swallowed word
3. **Advance plot** — reveal new information, force a decision, raise stakes
4. **Use sensory specificity** — numbers (12% oxygen), sounds (respirator hiss), physical weight
5. **Include dialogue with subtext** — what's not said matters as much as what is

**Before:**
> <p>The work continued through the long hours, each member of the team pushing themselves beyond the limits of exhaustion. They knew the window of opportunity was narrow — every moment of delay could mean the difference between success and failure.</p>

**After:**
> <p>Sarah's hands were raw from gripping the same valve for three hours. She couldn't feel her fingers anymore. But every time she thought about stopping, she pictured David's face — the way he'd looked at her before the extraction team left, trusting her to bring help. She hadn't brought help. She'd brought herself, and that would have to be enough.</p>

### Step 3: Bulk Replacement Script

```python
import re

replacements = [
    ('Old generic text...', 'New dramatic text...'),
    # One pair per generic phrase found
]

def quality_pass(path):
    with open(path) as f:
        html = f.read()
    changes = 0
    for generic, replacement in replacements:
        c = html.count(generic)
        if c > 0:
            html = html.replace(generic, replacement, c)
            changes += c
    if changes > 0:
        with open(path, "w") as f:
            f.write(html)
    return changes
```

### Step 4: Verify

```python
generic_phrases = [
    "the work continued", "in the silence of the", 
    "the data painted", "we're making progress",
    "the implications were", "the team gathered"
]

with open(path) as f:
    html = f.read()
    
remaining = sum(html.lower().count(p) for p in generic_phrases)
print(f"Generic phrases remaining: {remaining}")
```

Target: **zero** remaining generic phrases. A few false positives (matching inside dialogue)
are acceptable.

Before delivery, run one explicit final publication-polish pass on the assembled manuscript package.

**What to check in this final pass:**
- TOC cleanliness, indentation, dot leaders, and chapter/subsection order
- Exact or near-final TOC page numbers based on the rebuilt PDF
- Lingering grammar, punctuation, hyphenation, capitalization, and POV inconsistencies
- Duplicate or partially duplicated stories after manuscript merges
- Empty headings, placeholder text, production leftovers, and editor notes
- Correct image placement at chapter starts
- Clean front matter and back matter with no layout debris

**Deliver only after this step is complete.** If a known pagination instability remains because the TOC itself shifts page counts, state that caveat clearly with the delivered files.\n\n**WeasyPrint page-mapping workflow for exact TOC numbers:**\n- When building a print-ready HTML/PDF book, insert hidden text markers such as `PART_START_XX` and `CHAPTER_START_XX` into each part-divider page and chapter start.\n- Build the PDF once, extract text with `pypdf`, detect the first true body page, and compute TOC page numbers by searching for those markers from the body onward. This is more reliable than matching chapter titles alone and avoids false matches inside the TOC itself.\n- After writing the computed page numbers back into the TOC, rebuild and verify again.\n\n**WeasyPrint layout pitfall:**\n- Avoid float-based decorative drop caps in complex long-book layouts. In one real build, a floated `:first-letter` rule triggered a WeasyPrint layout assertion failure. Prefer a simple non-floating enlarged first letter if you want the effect without risking PDF generation failure.\n\n**Common pitfalls to avoid:**\n- Forgetting to sort chapter files numerically\n- Missing chapters due to file naming inconsistencies\n- Inconsistent formatting between front matter and chapters\n- Delivery to wrong chat target\n- Skipping the final polish pass after the PDF/HTML build\n- Using a noisy assembled manuscript file as the master source when a cleaner continuous manuscript also exists\n- Matching TOC page numbers from chapter titles alone without guarding against title hits inside the TOC pages\n
## Customization Options

**For different series:**
- Adjust front matter content to match series tone
- Modify chapter count and structure as needed
- Update author attribution and version info

**For different delivery platforms:**
- Telegram: Use `MEDIA:` prefix for documents
- Email: Attach file directly
- Discord: Use file upload with proper description

## Example Use Cases

1. **Series continuation:** Prepare Book 2 in a trilogy following the same format as Book 1
2. **Manuscript revision:** Update a completed book with new front matter for reprint
3. **Multi-format delivery:** Create different versions (Markdown, PDF, EPUB) for various reviewers
4. **Beta reader distribution:** Prepare clean, formatted copies for feedback

## Success Metrics

- All 64 chapters present and in correct order
- Front matter matches series style guide
- File delivered successfully to intended recipient
- Recipient can open and review without formatting issues

## Notes and Lessons Learned

- Always verify chapter count before consolidation
- Use version control for manuscript files when possible
- Keep templates for front matter to ensure consistency
- Test delivery on target platform beforehand if possible

## KDP Publishing Handoff (No-AI Login)

When the manuscript is fully prepared and ready for Kindle publishing, Amazon KDP blocks AI-driven logins. Use this browser handoff:

### Before the Handoff (AI Prepares)
1. Generate final EPUB manuscript file at a known path
2. Generate final cover PNG with typography
3. Create KDP AI Disclosure record
4. Build marketing copy (description, categories, keywords)
5. Prepare publishing package ZIP

### The Handoff (Shared Browser Session)
1. AI opens `https://kdp.amazon.com` via `browser_navigate`
2. AI calls `browser_vision` to show the login screen
3. AI tells Bob: *"Log into KDP — I'll wait."*
4. Bob enters credentials + 2FA manually in the shared browser
5. AI confirms login by navigating to the KDP bookshelf
6. AI clicks "+ Create" to start a new title
7. AI fills metadata (title, author, description, categories, keywords via browser_type)
8. AI tells Bob: *"Click Upload Manuscript and select: /path/to/book.epub"*
9. AI tells Bob: *"Click Upload Cover and select: /path/to/cover.png"*
10. AI guides pricing/royalty selection
11. AI checks AI disclosure checkbox
12. AI tells Bob: *"Click 'Publish Your Kindle eBook'"*
13. AI captures ASIN from confirmation screen
14. AI reports: *"Published! ASIN: XXXXXXXX — live within 72 hours."*

### Files to Have Ready
- Manuscript EPUB: `/path/to/BookName.epub`
- Cover PNG: `/path/to/BookName_Cover.png`
- AI Disclosure: `/path/to/KDP_AI_Disclosure.md`
- Marketing copy ready to paste into description field

## Multi-Book Series Restructuring (Content Redistribution Across N Volumes)

When a trilogy/series has imbalanced word counts per book and needs each volume to hit a target page range (e.g., 180-200 pages at 6×9in), use this workflow to redistribute content and set per-volume CSS to hit page targets.

### When to Use
- A series has one very long book (92k words) and other very short books (10k words)
- User says "each volume should be 180-200 pages" and content is uneven
- A single manuscript covers multiple eras/arcs that can be split across books
- You're writing bridge/transition content between the books
- **Books in different series are discovered to be duplicative** (same content, different character names) — you need to deduplicate before reflowing
- **Existing books across multiple named volumes need content shifted between them to balance page counts** (not splitting one manuscript, but redistributing existing volumes)
- Two books from different series appear to have identical or near-identical content (same chapter titles, same narrative structure) — run duplicate detection before any redistribution
- Existing books across multiple named volumes need content shifted between them to balance page counts (not splitting one manuscript, but redistributing existing volumes)

### Step 0: Duplicate Content Detection (Before Any Redistribution)

Before moving chapters between books, verify that books in separate series are genuinely unique. Two books from different series may share the same narrative structure and chapter titles with only character names swapped.

**Detection method:** Compare chapter titles and first-paragraph text across suspected-duplicate books:

```python
import re

def check_duplicates(path_a, path_b, label_a, label_b):
    """Compare chapter titles across two books for duplicate detection."""
    with open(path_a) as f:
        a = f.read()
    with open(path_b) as f:
        b = f.read()
    
    # Extract chapter titles
    a_titles = re.findall(r'<h1[^>]*>Chapter \d+[—–-]\s*(.+?)</h1>', a, re.DOTALL)
    b_titles = re.findall(r'<h1[^>]*>Chapter \d+[—–-]\s*(.+?)</h1>', b, re.DOTALL)
    
    if a_titles == b_titles:
        print(f"⚠️ {label_a} and {label_b} have IDENTICAL chapter titles ({len(a_titles)} chapters)")
        # Check first chapter body for name-swapped content
        a_body = re.search(r'<h1[^>]*>Chapter 1[^<]*</h1>\s*(.*?)(?=<h1)', a, re.DOTALL)
        b_body = re.search(r'<h1[^>]*>Chapter 1[^<]*</h1>\s*(.*?)(?=<h1)', b, re.DOTALL)
        if a_body and b_body:
            a_words = set(re.findall(r'\b[A-Z][a-z]+\b', re.sub(r'<[^>]+>', ' ', a_body.group(1))))
            b_words = set(re.findall(r'\b[A-Z][a-z]+\b', re.sub(r'<[^>]+>', ' ', b_body.group(1))))
            overlap = a_words & b_words
            print(f"   Shared proper nouns: {len(overlap)}/{len(a_words) + len(b_words) - len(overlap)}")
            if len(overlap) < 5:  # Different character names
                print(f"   → DUPLICATE with character names rotated")
                return True
        print(f"   → Likely DUPLICATE content")
        return True
    return False
```

**When duplicates are found:** One book from each duplicate pair must be rewritten as a distinct story before redistribution can proceed. Subagents timeout on full-book rewrites (23K+ words) — use `execute_code` with bulk paragraph expansion instead. After deduplication, verify the new content is truly unique by comparing sentence overlap: use `set(sentences_a) & set(sentences_b)` — overlap above 80% means the replacement still has structural debt.

### Per-Chapter Word Count Analysis

For planning redistribution, analyze each book's per-chapter word counts:

```python
import re

def analyze_book(path):
    """Print per-chapter word counts for a book HTML."""
    with open(path) as f:
        html = f.read()
    
    ch_pattern = re.compile(
        r'<h1[^>]*class="chapter-title"[^>]*>(.*?)</h1>(.*?)(?=<h1[^>]*class="chapter-title"|class="back-matter"|class="about"|$)',
### Multi-Book Series Restructuring (Content Redistribution Across N Volumes)

When a trilogy/series has imbalanced word counts per book and needs each volume to hit a target page range (e.g., 180-200 pages at 6×9in), use this workflow to redistribute content and set per-volume CSS to hit page targets.

### When to Use
- A series has one very long book (92k words) and other very short books (10k words)
- User says "each volume should be 180-200 pages" and content is uneven
- A single manuscript covers multiple eras/arcs that can be split across books
- You're writing bridge/transition content between the books
- **Books in different series are discovered to be duplicative** (same content, different character names) — you need to deduplicate before reflowing
- **Existing books across multiple named volumes need content shifted between them to balance page counts** (not splitting one manuscript, but redistributing existing volumes)
- **Books in different series are discovered to be duplicative** (same content, different character names) — you need to deduplicate before reflowing

### Step 0: Detect Duplicate Content Across Series

Before redistributing, audit all books for duplicates. Two books with different titles/series may contain the same content with rotated character names. Detection:

```bash
# Compare chapter titles between two suspect books
grep -c '<h1>Chapter' book_a.html book_b.html
diff <(grep '<h1>Chapter' book_a.html) <(grep '<h1>Chapter' book_b.html) | wc -l
# 0 lines diff = all chapter titles identical = probable duplicate
```

```python
# Compare body text sentence-by-sentence
import re
for path_a, path_b in [("book_a.html", "book_b.html")]:
    with open(path_a) as f: text_a = re.sub(r'<[^>]+>', ' ', f.read())
    with open(path_b) as f: text_b = re.sub(r'<[^>]+>', ' ', f.read())
    sentences_a = set(re.split(r'[.!?]+', text_a))
    sentences_b = set(re.split(r'[.!?]+', text_b))
    overlap = len(sentences_a & sentences_b) / max(len(sentences_a), len(sentences_b))
    print(f"Overlap: {overlap:.0%}")  # >90% = duplicate with name changes
```

**Fix duplicates by:** rewriting one series' books as completely new stories with original plots. Keep the chapter count (~20 chapters) but change the narrative (e.g., survival story → mystery thriller). Use the HTML template from the duplicate as a structural guide (CSS, front matter, TOC format).

### Bulk HTML Expansion Technique (Robust Across Formats)

When a book needs to grow from ~23K to ~46K words and the HTML is already formatted but short, use this `</p>`-insertion pattern. It is format-agnostic (works on `h1.chapter-title`, `h2>Chapter`, and plain `h1>Chapter` structures):

```python
import re

def bulk_expand_html(path, target_words, name, blocks=None):
    with open(path) as f:
        html = f.read()
    
    words_before = len(re.sub(r'<[^>]+>', ' ', html).split())
    needed = target_words - words_before
    if needed <= 0: return words_before
    
    # Find body content (after TOC/copyright, before back-matter)
    body_start = max(
        html.find('toc-page') if 'toc-page' in html else 0,
        html.find('<h1 class="chapter-title"'),
        html.find('<h2>Chapter'),
        html.find('<h1>Chapter')
    )
    body_end = html.find('class="back-matter"', body_start)
    if body_end < 0:
        body_end = html.find('About the Author', body_start)
    if body_end < 0:
        body_end = len(html)
    
    body = html[body_start:body_end]
    p_ends = [m.end() for m in re.finditer(r'</p>', body)]
    
    if len(p_ends) < 3:
        return words_before
    
    # Default expansion blocks (replace these with book-specific content)
    if blocks is None:
        blocks = [
            '<p class="scene-break">* * *</p><p>The work required patience... [content]</p>',
        ]
    
    words_per_block = 140
    insertions = min(needed // words_per_block, len(p_ends))
    step = max(1, len(p_ends) // insertions)
    offset = 0
    
    for idx in range(0, len(p_ends), step):
        block = blocks[idx % len(blocks)]
        pos = body_start + p_ends[idx] + offset
        html = html[:pos] + '\n' + block + html[pos:]
        offset += len(block) + 1
    
    words_after = len(re.sub(r'<[^>]+>', ' ', html).split())
    with open(path, "w") as f:
        f.write(html)
    return words_after

# Run up to 5 passes to converge on target
for _ in range(5):
    wc = bulk_expand_html(path, 46000, name)
    if wc >= 46000: break
```

**Key details:**
- **format-agnostic**: Uses all `</p>` tags, not chapter structure — works regardless of heading format
- **idempotent**: Multiple passes incrementally approach the target without overshooting by dividing remaining need each time
- **preserves structure**: Insertions go between existing paragraphs, not inside them
- **word budget**: Each insertion block should be ~130-200 words (adjust based on target)

### Step 1: Measure Total Content

Calculate the page budget:
```
Total words across all books: W
Target words per page: ~200-280 depending on typography
Target pages per book: P (e.g., 190)
Total words needed: P × 3 × 250 ≈ 142,500 words (for 3 books at 190 pages, 250 wpp)
```

At 11pt Georgia, 1.55 line-height, 0.85in margins on 6×9in: ~200-210 words/page
At 10.5pt, 1.45 / 0.75in: ~240 words/page
At 10pt, 1.4 / 0.75in: ~260 words/page
At 9.5pt, 1.35 / 0.7in: ~280 words/page

Python word counter for checking HTML content:
```python
import re
with open(path) as f:
    html = f.read()
words = len(re.sub(r'<[^>]+>', ' ', html).split())
pages = words / 220  # ~220 wpp at 11.5pt Georgia
```

### Step 2: Identify the Split Point

For the long book, find the natural chapter boundary closest to the target word count:
```python
chapters = [...]  # list of (heading, word_count)
target_words = target_pages * expected_wpp
cumulative = 0
for i, (heading, wc) in enumerate(chapters):
    cumulative += wc
    if cumulative >= target_words:
        print(f"Split after Chapter {i+1}: {cumulative} words")
        break
```

**Chapter boundary detection across HTML formats:** Books use different heading structures. Find chapters with this format-agnostic approach:

```python
import re
with open(path) as f: html = f.read()

# Try patterns in order of specificity
ch_starts = []
for pattern in [
    r'<h1[^>]*class="chapter-title"[^>]*>.*?</h1>',  # <h1 class="chapter-title">
    r'<h2>Chapter \d+.*?</h2>',                      # <h2>Chapter N
    r'<h1>Chapter \d+.*?</h1>',                      # <h1>Chapter N
]:
    ch_starts = [m.end() for m in re.finditer(pattern, html, re.DOTALL)]
    if len(ch_starts) >= 2: break  # Found valid chapters
```

### Step 3: Redistribute Content Across N Books

Keep narrative integrity — split at escalation points, time jumps, or perspective shifts.

**When books in a series have different storylines** (e.g., Book 2 is a political saga, Book 3 is an alien-contact story, Books 4-5 are the prequel), you CANNOT simply move chapters between books. Instead:
- Expand short books by **fleshing out existing chapters** (doubling scene depth, adding dialogue, sensory detail)
- For overlength books, **split at narrative climax points** and move the resolution arc to other books as "meanwhile" interludes
- Then rewrite first/last chapters of each book to create **transition hooks** between volumes

**When content is continuous across books** (same narrative, chapters numbered sequentially): move chapter blocks from the overlength book to the underlength books at natural breaking points.

Example (140k total words → 3 books at ~47k each):
- **Book I**: Shortest existing book (10k) + first ~40% of the long book (37k) + bridge transition
- **Book II**: Middle ~45% of the long book (42k)
- **Book III**: Remaining ~15% of the long book (13k) + third existing book (36k) = 49k
  (Adjust percentages based on actual chapter-word-count data)

### Step 4: Write Bridge Content

When content from different eras/books is combined in one volume, write a transition:
- **Time jump bridge**: 500-1000 words explaining what happened in the gap years (key events, technological shifts, societal changes)
- **Tonal bridge**: When combining a survival story with a political thriller, acknowledge the shift through a character's perspective
- **Series bridge**: Write a chapter that connects the themes of the earlier book to the coming conflict
- **First/last chapter hooks**: Each book needs an opening that recalls the previous book's ending and a closing that sets up the next. Write these as 200-500 word additions inserted at the beginning of Chapter 1 and end of the last chapter:
  ```python
  # First chapter: insert after the </h1> of the first chapter heading
  h1_end = html.find('</h1>', ch_start)
  html = html[:h1_end+5] + '\n' + transition_text + html[h1_end+5:]
  
  # Last chapter: insert before the back-matter
  back_start = html.find('class="back-matter"')
  last_p = html[:back_start].rfind('</p>')
  html = html[:last_p+4] + '\n' + transition_text + html[last_p+4:]
  ```

### Step 5: Set Per-Volume CSS to Hit Page Target

Use per-book CSS adjustments so each volume lands in the 180-200 page range:

```python
# Book I: 40k words → 203 pages (11pt, 1.55 line-height, 0.85in margins)
css_I = """
@page { size: 6in 9in; margin: 0.85in; }
body { font-family: Georgia, serif; line-height: 1.55; font-size: 11pt; }
p { margin: 0.15em 0; text-indent: 1.2em; }
"""

# Book II: 62k words → 197 pages (9.5pt, 1.35 line-height, 0.7in margins)
css_II = """
@page { size: 6in 9in; margin: 0.7in; }
body { font-family: Georgia, serif; line-height: 1.35; font-size: 9.5pt; }
p { margin: 0.08em 0; text-indent: 0.9em; }
"""

# Book III: 40k words → 194 pages (11pt, 1.55 line-height, 0.85in margins)
css_III = css_I  # Same as Book I if word count is similar
```

After setting CSS, rebuild and verify with `pdfinfo | grep Pages`. Adjust line-height or margins by ±0.05 increments until each book lands in range.

### Step 6: Generate Review PDFs

Build each book's HTML with its own CSS, then convert with WeasyPrint. Verify:
```bash
pdfinfo Book_*_Review.pdf | grep -E 'Pages|Page size'
```
Page size must be **432 × 648 pts** (= 6×9in). If you see 595×842 (A4), the `@page` CSS was stripped or invalid.

### Step 7: Update the Series Package

Recreate the package directory with per-book subdirectories:
```
Series_Name/
├── Book_I_Title/
│   ├── manuscript.md
│   └── Book_I_Review.pdf
├── Book_II_Title/
│   ├── manuscript.md
│   └── Book_II_Review.pdf
└── Book_III_Title/
    ├── manuscript.md
    └── Book_III_Review.pdf
```

### Pitfalls
- **Do NOT rebuild book HTML from PDF text extraction.** The `pdftotext` command consistently loses 25-50% of content from WeasyPrint-generated PDFs, regardless of extraction options (`-raw`, `-layout`, `-nopgbrk`). Loss occurs silently — the extracted text looks complete but has far fewer words. Instead: keep the original HTML as the master source. Use manuscript.md as fallback. Use EPUB files as intermediate backup (EPUBs generated before compression passes preserve full content).
### Duplicate Content Detection Across Series

When restructuring multi-book series, ALWAYS check for duplicate content between books in different series. This session discovered that **Books 4 and 6** and **Books 5 and 7** in different series (No Blue Sky and Lunar Foundation) were identical content with only character names rotated.

**Detection method:**
```python
# Compare chapter titles between two books
titles_4 = [extract titles from Book 4 HTML]
titles_6 = [extract titles from Book 6 HTML]

# If 90%+ match, check first chapter body text word-for-word
# If body text also matches (only names differ), they are duplicates
```
When duplicates are found, rewrite one version as a **completely distinct story** in the same setting. For example, rewrite a "Moon base establishment" story as a "survival thriller" or "conspiracy mystery" set on the same Moon base but with different characters and plot.

### Quality Improvement Pass (Generic-to-Dramatic Replacement)

After expanding books to hit page targets with bulk content additions, run a **quality improvement pass** to replace all generic placeholder paragraphs with dramatic, character-driven content.

**Generic phrases to detect and replace:**
- "The work continued through the long hours..."
- "In the silence of the habitat..."
- "The data painted a complex picture..."
- "We're making progress, slowly..."
- "The implications were staggering..."
- "The team gathered around the monitor..."
- "We need to consider all possibilities..."
- "The situation demanded action..."
- "Time was running out..."
- "We're not going to survive this if we keep arguing..."

**Replacement strategy:** Replace each generic phrase with scene-specific content that has:
- **Named characters** (not "someone" or "the team")
- **Specific actions** (not "they worked" but "Sarah cranked the valve")
- **Sensory details** (temperature, light, sound, physical sensation)
- **Emotional beats** (fear, anger, hope, exhaustion shown through actions)
- **Dialogue** with conflict or revelation
- **Rising stakes** (ticking clock, limited resources, personal cost)

**Automated approach:**
```python
replacements = [
    ("The work continued through the long hours...", "Sarah's hands were raw..."),
    ("In the silence of the habitat...", "The only sound was Marta's breathing..."),
    # ...30+ replacement pairs for all known generic phrases
]

for generic, replacement in replacements:
    count = html.count(generic)
    if count > 0:
        html = html.replace(generic, replacement, count)
```

After replacement, verify: 0 occurrences of any generic phrase remain. Run this on all expanded books before delivering final PDFs.

### Handling Book 8 Overflow (Split & Recombine)

When the last book in a series exceeds 200 pages after reflow:

1. **First**: Check if the full book fits 180-200 pages with proper CSS (some books compress well at 11pt/1.45lh/0.75in margins). The PDF render may give different results than estimation.
2. **If still over**: Split at a natural narrative break point (chapter boundary with a thematic transition). Renumber the split chapters.
3. **If the split books are both too short (<150 pages)**: Recombine them. The original single book may actually fit 180-200 pages when rendered — always render a PDF to verify before permanently splitting.
4. **Expand if needed**: If a split offload book has too few words for 190 pages, expand it with new content (character development, subplots, parallel storylines).

### Pitfalls
- Word-per-page rates vary significantly by font, line-height, and margins. Always build-and-verify rather than relying on calculation.
- `@page` CSS with nested `@bottom-center` rules can be stripped by some WeasyPrint versions. Validate page size after every build.
- Chapter headings with forced `page-break-before` eat ~3-5 pages per 40-chapter book (one heading per chapter × partial page waste). Factor this into your page budget.
- Bridge content must match the narrative voice and POV of both adjacent books. A first-person bridge followed by a third-person chapter reads as two different authors.
- When splitting a long manuscript, check for duplicate character intros or setting descriptions at the split boundary — the author may have written both as "first chapter" material.
- **Duplicate series detection**: When two books in different series have the exact same chapter titles and similar word counts, they are likely duplicates with rotated character names. Always check before running the full pipeline.
- **PDF text extraction loses content**: `pdftotext` may capture only 50-65% of the PDF's word count when extracting text for rebuilding HTML. Use original HTML or EPub sources instead when rebuilding.
- **Quality pass must come last**: Run the generic-to-dramatic replacement AFTER final word count targeting. The replacement adds words (each replacement is longer than the original generic text), which shifts page counts.

### Example
This workflow was used to restructure the No Blue Sky and Lunar Foundation series: