---
name: manuscript-preparation-and-delivery
description: Workflow for preparing completed manuscripts for review and delivery, including file consolidation, front matter creation, and messaging platform delivery
category: creative
---

# Manuscript Preparation and Delivery