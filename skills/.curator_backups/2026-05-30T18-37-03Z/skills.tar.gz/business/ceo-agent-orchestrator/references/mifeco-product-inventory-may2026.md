# MIFECO Product Line Inventory — May 30, 2026

> Snapshot of all MIFECO product lines. Last updated: 2026-05-30.
> **Always run a fresh `ls ~/books/` scan** — this file can be stale.

---

## 1. SaaS — Cloud Run Apps (ALL OPERATIONAL as of May 28)

| App | URL | Status | Key Issues |
|-----|-----|--------|------------|
| Project Hypatia Pro | project-hypatia-pro-1064319572465.us-west1.run.app | ✅ Operational | No security headers deployed, no onboarding flow |
| PM Accelerator | project-management-accelerator-845075991286.us-west1.run.app | ✅ Operational | No security headers; SQLite crash risk (writes to ./db) |
| VibraEngineer | vibraengineer-845075991286.us-west1.run.app | ✅ Operational | No security headers; CORS wildcard; SQLite crash risk |
| mifeco.com | mifeco.com | ✅ Operational | All 6 security headers present |

**Known:** gcloud CLI NOT installed — all deployments blocked. Security headers fix coded May 7, never deployed.

---

## 2. Books Pipeline — 11 of 19 books have KDP_PACKAGE + zip

**Total: 19 books** (Business Series has 3 books as of May 30).

### KDP_PACKAGE status:
- ✅ **Have KDP_PACKAGE + zip (11):** LF4 Waters_Horizon, AL1 Sunward_Exodus, AL2-4 Age_of_Lightships (dirs only, empty — 0 content), Tomorrow_Remembered, Tomorrow_is_Still_Open, AI_That_Works (standardized May 28), Owners_Manual_AI_Agents, The_Crisis_Ready_Company (+zip May 30), NBS IV Red_Charter, NBS V First_Martian_Nation

### KDP_PACKAGE dir vs .zip distinction:
- 11 books have BOTH directory AND .zip ✅
- 3 books (AL B2 Mercury_Accord, AL B3 Ghosts_Beyond_Neptune, AL B4 Last_Photon_Fleet) have EMPTY KDP_PACKAGE dirs with <10 files — these are shells needing chapters, not packaging
- 4 books have Publishing_Package.zip (old format) but no KDP_PACKAGE dir: NBS I Built_from_Dust, NBS II Oxygen_Gamble, NBS III Rivers_Under_Mars, Owners_Manual_AI_Agents

### Series:
- **No Blue Sky** (5 books) — B1-3 have epub + Pub_zip; B4-5 have KDP dir + zip. ALL 5 have complete manuscripts (NBS IV, V have 7 chapters each — may be complete novellas)
- **Lunar Foundation** (4 books) — ALL 4 have KDP dir + zip ✅
- **Age of Lightships** (4 books) — B1 has KDP dir + zip ✅; B2-4 have EMPTY KDP dirs with 0 chapters (need ~120 chapters written)
- **Tomorrow** (2 books) — Both done (Remembered + Still_Open)
- **Business** (3 books) — AI_That_Works ✅; Crisis_Ready_Company ✅; Owners_Manual has Pub_zip

---

## 3. Consulting Pipeline — STALLED

- 10 leads, 0 contacted
- Outreach packet + EdTech one-pager ready
- No email infrastructure
- consultant agent: OFFLINE (Cycle 2)

---

## 4. Agent Status (May 30)

| Agent | Status | Cycle |
|-------|--------|-------|
| brand-advocate | 🔴 OFFLINE | 3+ |
| consultant | 🔴 OFFLINE | 2 |
| sales | 🔴 OFFLINE | 1 |
| engineer | ⚠️ Weak ghosting | 1 |
| security | ⚠️ Weak ghosting | 1 |
| researcher | 🟢 Watch | 1 (2 pending, within SLA) |
| publisher | 🔴 OFFLINE | 2 |
| writer | ✅ Active | — |

## 5. Critical SaaS Findings (May 30)

- **SQLite crash risk:** VibraEngineer + PM Accelerator write `./database.sqlite` — crashes on Cloud Run (read-only FS except `/tmp`). Must change to `/tmp/database.sqlite` before deploying.
- **Deployment runbook created:** `references/deployment-runbook-may2026.md` (24,765 bytes). Contains exact gcloud commands + SQLite fix + rollback.
- **CDN status:** Resolved as of May 26. Monitor for regression.
- **Security headers:** Still not deployed (gcloud blocker since May 7 = 23 days).
| App | URL | Status | Key Issues |
|-----|-----|--------|------------|
| Project Hypatia Pro | project-hypatia-pro-1064319572465.us-west1.run.app | ✅ Operational | No security headers deployed; no onboarding flow |
| PM Accelerator | project-management-accelerator-845075991286.us-west1.run.app | ✅ Operational | No security headers; SQLite crash risk |
| VibraEngineer | vibraengineer-845075991286.us-west1.run.app | ✅ Operational | No security headers; CORS wildcard; SQLite crash risk; Tailwind CDN warning |
| mifeco.com | mifeco.com | ✅ Operational | All 6 security headers present |

**Known:** gcloud CLI NOT installed — all deployments blocked. Security headers fix coded May 7, never deployed.
